import { createFileRoute } from "@tanstack/react-router";
import { KaihApp } from "@/components/kaih/app";

export const Route = createFileRoute("/")({ component: KaihApp });

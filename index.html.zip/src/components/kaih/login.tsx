import { useState } from "react";
import { toast } from "sonner";
import { IdCard, LogIn, UserPlus } from "lucide-react";
import { KELAS_LIST, MONITOR_NISN, WA_ADMIN } from "@/lib/kaih/model";
import { login, register } from "@/lib/kaih/store";
import { Button, fieldClass } from "@/components/kaih/ui";

export function LoginScreen() {
  const [mode, setMode] = useState<"masuk" | "daftar">("masuk");
  const [nisn, setNisn] = useState("");
  const [nama, setNama] = useState("");
  const [kelas, setKelas] = useState(KELAS_LIST[0]);
  const [notice, setNotice] = useState("");

  function onNisn(value: string) {
    setNisn(value.replace(/\D/g, "").slice(0, 10));
  }

  function submitLogin(value = nisn) {
    const result = login(value);
    if (result === "ok" || result === "monitor") return;
    if (result === "empty") {
      toast.error("Masukkan NISN terlebih dahulu.");
      return;
    }
    if (result === "invalid") {
      toast.error("NISN harus 10 digit angka.");
      return;
    }
    setMode("daftar");
    setNotice("NISN belum terdaftar. Lengkapi data di bawah, lalu kamu langsung masuk ke Home.");
  }

  function submitRegister() {
    const error = register({ nisn, nama, kelas });
    if (error) {
      toast.error(error);
      return;
    }
    toast.success("Pendaftaran berhasil. Selamat datang di Home.");
  }

  const help = `https://wa.me/${WA_ADMIN}?text=${encodeURIComponent("Halo Admin, saya membutuhkan bantuan terkait Jurnal KAIH.")}`;

  return (
    <div className="flex min-h-screen items-center justify-center bg-kaih-paper px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 flex flex-col items-center text-center">
          <img src="/logo-kaih.png" alt="Logo SMA Negeri 1 Kartasura" className="mb-3 h-28 w-auto object-contain" />
          <h1 className="text-2xl font-extrabold text-kaih-ink">Jurnal KAIH</h1>
          <p className="mt-1 text-sm text-kaih-muted">Kebiasaan Anak Indonesia Hebat · SMA Negeri 1 Kartasura</p>
        </div>

        <div className="rounded-3xl border border-kaih-line bg-kaih-card p-6 shadow-sm">
          <div className="mb-5 grid grid-cols-2 gap-2 rounded-xl bg-kaih-paper p-1">
            <button
              type="button"
              className={`min-h-11 rounded-lg text-sm font-bold ${mode === "masuk" ? "bg-kaih-card text-kaih-ink shadow-sm" : "text-kaih-muted"}`}
              onClick={() => {
                setMode("masuk");
                setNotice("");
              }}
            >
              Masuk
            </button>
            <button
              type="button"
              className={`min-h-11 rounded-lg text-sm font-bold ${mode === "daftar" ? "bg-kaih-card text-kaih-ink shadow-sm" : "text-kaih-muted"}`}
              onClick={() => setMode("daftar")}
            >
              Daftar
            </button>
          </div>

          {notice ? <p className="mb-4 rounded-xl bg-kaih-soft-amber px-3 py-2 text-sm text-kaih-gold">{notice}</p> : null}

          <label className="mb-2 block text-sm font-semibold text-kaih-ink" htmlFor="nisn">
            NISN
          </label>
          <div className="relative">
            <IdCard className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-kaih-muted" />
            <input
              id="nisn"
              inputMode="numeric"
              autoComplete="username"
              maxLength={10}
              placeholder="10 digit NISN"
              value={nisn}
              onChange={(event) => onNisn(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && mode === "masuk") submitLogin();
              }}
              className={`${fieldClass} pl-10 tracking-widest`}
            />
          </div>

          {mode === "daftar" ? (
            <div className="mt-4 space-y-3">
              <div>
                <label className="mb-2 block text-sm font-semibold" htmlFor="nama">
                  Nama lengkap
                </label>
                <input id="nama" value={nama} onChange={(event) => setNama(event.target.value)} className={fieldClass} />
              </div>
              <div>
                <label className="mb-2 block text-sm font-semibold" htmlFor="kelas">
                  Kelas
                </label>
                <select id="kelas" value={kelas} onChange={(event) => setKelas(event.target.value)} className={fieldClass}>
                  {KELAS_LIST.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>
              <Button className="mt-2 w-full" onClick={submitRegister}>
                <UserPlus className="size-4" />
                Daftar dan masuk Home
              </Button>
            </div>
          ) : (
            <Button className="mt-5 w-full" onClick={() => submitLogin()}>
              <LogIn className="size-4" />
              Masuk ke Home
            </Button>
          )}
        </div>

        <div className="mt-4 flex flex-col items-center gap-2 text-center">
          <button
            type="button"
            className="min-h-11 text-sm font-semibold text-kaih-amber"
            onClick={() => {
              setNisn("0012345001");
              setMode("masuk");
              submitLogin("0012345001");
            }}
          >
            Coba data contoh · Ahmad Fauzan
          </button>
          <p className="text-xs text-kaih-muted">
            Pantauan guru memakai NISN {MONITOR_NISN}.{" "}
            <a className="font-semibold text-kaih-emerald" href={help} target="_blank" rel="noreferrer">
              Bantuan WhatsApp
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

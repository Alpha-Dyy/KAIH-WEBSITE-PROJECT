import { toast } from "sonner";
import { Lock, Save } from "lucide-react";
import {
  calcScore,
  fmtDateLong,
  HABITS,
  MAX_TOTAL_POIN,
  MOOD_META,
  moodFor,
  scoreMeta,
  todayStr,
  type Habit,
} from "@/lib/kaih/model";
import {
  currentStudent,
  jurnalLocked,
  openJurnal,
  saveJurnal,
  setRefleksi,
  toggleOption,
  useKaih,
} from "@/lib/kaih/store";
import { HABIT_ICONS } from "@/components/kaih/icons";
import { Button, Card } from "@/components/kaih/ui";

const moodStyle = {
  smile: "border-kaih-emerald bg-kaih-soft-emerald",
  flat: "border-kaih-gold bg-kaih-soft-amber",
  sad: "border-kaih-danger bg-kaih-soft-danger",
} as const;

export function JurnalView() {
  const snapshot = useKaih();
  const student = currentStudent(snapshot);
  if (!student) return null;
  const locked = jurnalLocked(snapshot);
  const score = calcScore(snapshot.selections);
  const shown = Object.keys(snapshot.selections).length ? scoreMeta(score.percent) : scoreMeta(null);
  const ring = 2 * Math.PI * 28;
  const offset = ring - (score.percent / 100) * ring;
  const stroke =
    shown.tone === "good"
      ? "var(--color-kaih-emerald)"
      : shown.tone === "mid"
        ? "var(--color-kaih-amber)"
        : shown.tone === "low"
          ? "var(--color-kaih-danger)"
          : "var(--color-kaih-line)";

  function onSave() {
    const result = saveJurnal();
    if (!result.ok) toast.error(result.message);
    else toast.success(result.message);
  }

  return (
    <div className="space-y-4">
      <div>
        <p className="text-xs font-bold tracking-wide text-kaih-amber uppercase">Jurnal</p>
        <h1 className="text-2xl font-extrabold">Pengisian Jurnal KAIH</h1>
        <p className="mt-1 text-sm text-kaih-muted">
          Tombol paling atas bereaksi senyum, tombol tengah datar, dan tombol paling bawah sedih.
        </p>
      </div>

      <Card className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <label className="text-sm font-semibold">
          Tanggal pencatatan
          <input
            type="date"
            max={todayStr()}
            value={snapshot.jurnalDate}
            onChange={(event) => openJurnal(event.target.value || todayStr())}
            className="mt-2 block min-h-11 rounded-xl border border-kaih-line bg-kaih-card px-3 text-sm font-semibold"
          />
        </label>
        <div className="sm:text-right">
          <p className="font-bold">{fmtDateLong(snapshot.jurnalDate)}</p>
          <p className={`text-sm font-semibold ${locked ? "text-kaih-danger" : "text-kaih-muted"}`}>
            {locked ? "Sudah diisi dan terkunci" : "Belum diisi"}
          </p>
        </div>
      </Card>

      {locked ? (
        <p className="rounded-xl bg-kaih-soft-danger px-4 py-3 text-sm text-kaih-danger">
          Jurnal tanggal ini sudah disimpan. Setiap tanggal hanya bisa diisi satu kali.
        </p>
      ) : null}

      {snapshot.celebrate !== null && locked ? (
        <p className="rounded-xl bg-kaih-soft-emerald px-4 py-3 text-sm font-semibold text-kaih-emerald">
          {snapshot.celebrate >= 80 ? `${MOOD_META.smile.emoji} ` : ""}
          Jurnal tersimpan dengan skor {snapshot.celebrate}%.
        </p>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2">
        {HABITS.map((habit) => (
          <HabitCard key={habit.key} habit={habit} locked={locked} />
        ))}
      </div>

      <Card>
        <label className="mb-2 block text-sm font-bold" htmlFor="refleksi">
          Refleksi harian
        </label>
        <textarea
          id="refleksi"
          rows={3}
          disabled={locked}
          value={snapshot.refleksi}
          placeholder="Ceritakan momen berkesan atau tindakan kebaikan hari ini."
          onChange={(event) => setRefleksi(event.target.value)}
          className="w-full resize-none rounded-xl border border-kaih-line bg-kaih-card px-3 py-3 text-sm outline-none focus:border-kaih-amber disabled:bg-kaih-paper"
        />
      </Card>

      <Card className="flex flex-col items-stretch gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <div className="relative size-16 shrink-0">
            <svg className="size-16 -rotate-90" viewBox="0 0 64 64" aria-hidden="true">
              <circle cx="32" cy="32" r="28" fill="none" stroke="var(--color-kaih-line)" strokeWidth="7" />
              <circle
                cx="32"
                cy="32"
                r="28"
                fill="none"
                stroke={stroke}
                strokeWidth="7"
                strokeLinecap="round"
                strokeDasharray={ring.toFixed(1)}
                strokeDashoffset={offset.toFixed(1)}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center text-sm font-extrabold">{score.percent}%</div>
          </div>
          <div>
            <p className="text-xs font-semibold text-kaih-muted">Skor hari ini</p>
            <p className="text-lg font-extrabold">
              {score.total} / {MAX_TOTAL_POIN} poin
            </p>
            <p className="text-xs font-bold text-kaih-gold">{shown.label}</p>
          </div>
        </div>
        {locked ? (
          <Button tone="secondary" onClick={() => toast.error("Jurnal ini sudah terkunci.")}>
            <Lock className="size-4" />
            Sudah terkunci
          </Button>
        ) : (
          <Button onClick={onSave}>
            <Save className="size-4" />
            Simpan jurnal hari ini
          </Button>
        )}
      </Card>
    </div>
  );
}

function HabitCard({ habit, locked }: { habit: Habit; locked: boolean }) {
  const snapshot = useKaih();
  const sel = snapshot.selections[habit.key];
  const Icon = HABIT_ICONS[habit.key];
  const selectedIndex = habit.type === "radio" && typeof sel === "number" ? sel : null;
  const reaction =
    snapshot.lastReaction?.habit === habit.key ? snapshot.lastReaction : null;
  const captionIndex = reaction?.index ?? selectedIndex;
  const caption =
    captionIndex !== null && (habit.type === "radio" || (Array.isArray(sel) && sel.includes(captionIndex)))
      ? MOOD_META[moodFor(captionIndex, habit.options.length)]
      : null;

  return (
    <Card className="overflow-hidden">
      <div className="mb-3 flex items-center gap-2.5">
        <span className="flex size-9 items-center justify-center rounded-lg bg-kaih-soft-amber text-kaih-amber">
          <Icon className="size-4" />
        </span>
        <h2 className="text-sm font-extrabold">{habit.title}</h2>
      </div>
      <div className="space-y-2">
        {habit.options.map((option, index) => {
          const checked = habit.type === "radio" ? sel === index : Array.isArray(sel) && sel.includes(index);
          const mood = moodFor(index, habit.options.length);
          const popping = reaction?.index === index && reaction.nonce && checked;
          return (
            <button
              key={option.label}
              type="button"
              aria-pressed={checked}
              onClick={() => {
                const result = toggleOption(habit.key, index);
                if (result.locked) toast.error("Jurnal tanggal ini sudah terkunci.");
              }}
              className={`flex min-h-11 w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left ${
                checked ? moodStyle[mood] : "border-kaih-line bg-kaih-card"
              }`}
            >
              <span
                className={`flex size-5 shrink-0 items-center justify-center border-2 ${
                  habit.type === "radio" ? "rounded-full" : "rounded-md"
                } ${checked ? "border-current" : "border-kaih-line"}`}
              >
                {checked ? <span className="size-2.5 rounded-full bg-current" /> : null}
              </span>
              <span className="flex-1 text-sm font-medium">{option.label}</span>
              {checked ? (
                <span key={popping ? reaction?.nonce : option.label} className={`text-xl ${popping ? "mood-pop" : ""}`} aria-hidden="true">
                  {MOOD_META[mood].emoji}
                </span>
              ) : null}
            </button>
          );
        })}
      </div>
      {caption ? (
        <p key={reaction?.nonce ?? selectedIndex} className="mood-pop mt-3 text-sm font-semibold">
          {caption.emoji} {caption.line}
        </p>
      ) : (
        <p className="mt-3 text-xs text-kaih-muted">
          {habit.type === "checkbox" ? "Boleh memilih lebih dari satu." : "Pilih satu jawaban."}
        </p>
      )}
      {locked ? <span className="sr-only">Terkunci</span> : null}
    </Card>
  );
}

import {
  badgeCount,
  HABIT_BADGE_TARGET,
  HABITS,
  logsFor,
  todayStr,
  TROPHIES,
  fmtDateShort,
} from "@/lib/kaih/model";
import { currentStudent, goHome, setLencanaRange, useKaih } from "@/lib/kaih/store";
import { HABIT_ICONS, TROPHY_ICONS } from "@/components/kaih/icons";
import { Button, Card, SectionTitle } from "@/components/kaih/ui";

export function LencanaView() {
  const snapshot = useKaih();
  const student = currentStudent(snapshot);
  if (!student) return null;
  const mine = logsFor(snapshot.logs, student.nisn);
  const from = snapshot.lencanaFrom <= snapshot.lencanaTo ? snapshot.lencanaFrom : snapshot.lencanaTo;
  const to = snapshot.lencanaFrom <= snapshot.lencanaTo ? snapshot.lencanaTo : snapshot.lencanaFrom;
  const period = mine.filter((log) => log.date >= from && log.date <= to);
  const periodPoints = period.reduce((acc, log) => acc + log.totalPoin, 0);
  const allPoints = mine.reduce((acc, log) => acc + log.totalPoin, 0);

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-bold tracking-wide text-kaih-amber uppercase">Prestasi</p>
          <h1 className="text-2xl font-extrabold">Lencana & Prestasi</h1>
        </div>
        <Button tone="secondary" onClick={goHome}>
          Kembali ke Home
        </Button>
      </div>

      <Card>
        <SectionTitle kicker="Periode" title="Perolehan poin" />
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <label className="text-sm font-semibold">
            Dari
            <input
              type="date"
              max={todayStr()}
              value={snapshot.lencanaFrom}
              onChange={(event) => setLencanaRange(event.target.value, snapshot.lencanaTo)}
              className="mt-1 block min-h-11 rounded-xl border border-kaih-line px-3"
            />
          </label>
          <label className="text-sm font-semibold">
            Sampai
            <input
              type="date"
              max={todayStr()}
              value={snapshot.lencanaTo}
              onChange={(event) => setLencanaRange(snapshot.lencanaFrom, event.target.value)}
              className="mt-1 block min-h-11 rounded-xl border border-kaih-line px-3"
            />
          </label>
        </div>
        <p className="mt-4 text-sm font-bold text-kaih-gold">
          {periodPoints} poin pada {fmtDateShort(from)} – {fmtDateShort(to)}
          <span className="font-medium text-kaih-muted"> · {allPoints} poin sepanjang waktu</span>
        </p>
      </Card>

      <div>
        <h2 className="mb-3 text-sm font-extrabold">Piala utama</h2>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {TROPHIES.map((trophy) => {
            const unlocked = periodPoints >= trophy.target;
            const progress = Math.min(100, Math.round((periodPoints / trophy.target) * 100));
            const Icon = TROPHY_ICONS[trophy.key];
            return (
              <Card key={trophy.key} className="text-center">
                <div
                  className={`mx-auto mb-2 flex size-14 items-center justify-center rounded-full ${
                    unlocked ? "bg-kaih-emerald text-kaih-on" : "bg-kaih-paper text-kaih-muted"
                  }`}
                >
                  <Icon className="size-6" />
                </div>
                <p className={`text-xs font-bold ${unlocked ? "text-kaih-ink" : "text-kaih-muted"}`}>{trophy.label}</p>
                <p className="mt-1 text-xs text-kaih-muted">
                  {periodPoints}/{trophy.target}
                </p>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-kaih-paper">
                  <div className="h-full rounded-full bg-kaih-amber" style={{ width: `${progress}%` }} />
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      <div>
        <h2 className="mb-3 text-sm font-extrabold">Lencana kebiasaan</h2>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {HABITS.map((habit) => {
            const count = badgeCount(period, habit);
            const unlocked = count >= HABIT_BADGE_TARGET;
            const progress = Math.min(100, Math.round((count / HABIT_BADGE_TARGET) * 100));
            const Icon = HABIT_ICONS[habit.key];
            return (
              <Card key={habit.key} className="text-center">
                <div
                  className={`mx-auto mb-2 flex size-14 items-center justify-center rounded-full ${
                    unlocked ? "bg-kaih-soft-emerald text-kaih-emerald" : "bg-kaih-paper text-kaih-muted"
                  }`}
                >
                  <Icon className="size-6" />
                </div>
                <p className="text-xs font-bold">{habit.short}</p>
                <p className="mt-1 text-xs text-kaih-muted">
                  {count}/{HABIT_BADGE_TARGET} kali maksimal
                </p>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-kaih-paper">
                  <div className="h-full rounded-full bg-kaih-emerald" style={{ width: `${progress}%` }} />
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}

import { House, LogOut } from "lucide-react";
import { clsx } from "clsx";
import type { ReactNode } from "react";
import { currentStudent, goHome, logout, useKaih } from "@/lib/kaih/store";

export function Shell({ children }: { children: ReactNode }) {
  const snapshot = useKaih();
  const student = currentStudent(snapshot);
  if (!student) return null;
  const home = snapshot.view === "home";

  return (
    <div className="min-h-screen bg-kaih-paper text-kaih-ink">
      <header className="sticky top-0 z-30 border-b border-kaih-line bg-kaih-card/95 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center gap-2 px-4 py-2.5 sm:gap-3">
          <img src="/logo-kaih.png" alt="Logo SMA Negeri 1 Kartasura" className="h-12 w-auto shrink-0 object-contain" />
          <button
            type="button"
            onClick={goHome}
            className={clsx(
              "inline-flex min-h-11 items-center gap-2 rounded-full px-4 text-sm font-bold",
              home ? "bg-kaih-amber text-kaih-on" : "text-kaih-ink hover:bg-kaih-soft-amber",
            )}
          >
            <House className="size-4" />
            Home
          </button>
          <p className="hidden text-sm font-extrabold text-kaih-ink sm:block">Jurnal KAIH</p>
          <div className="ml-auto flex items-center gap-2">
            <div className="hidden text-right leading-tight sm:block">
              <p className="max-w-40 truncate text-sm font-bold">{student.nama}</p>
              <p className="text-xs text-kaih-muted">{student.kelas}</p>
            </div>
            <div className="flex size-11 items-center justify-center rounded-full bg-kaih-soft-amber text-sm font-extrabold text-kaih-amber">
              {student.nama.trim().charAt(0).toUpperCase()}
            </div>
            <button
              type="button"
              onClick={logout}
              aria-label="Keluar"
              title="Keluar"
              className="inline-flex size-11 items-center justify-center rounded-xl text-kaih-muted hover:bg-kaih-soft-amber hover:text-kaih-ink"
            >
              <LogOut className="size-4" />
            </button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-6">{children}</main>
    </div>
  );
}

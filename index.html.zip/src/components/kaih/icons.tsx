import {
  Bed,
  BookOpen,
  Flag,
  Footprints,
  HeartHandshake,
  PersonStanding,
  Star,
  Sun,
  TrendingUp,
  Users,
  Utensils,
  type LucideIcon,
} from "lucide-react";
import type { HabitKey } from "@/lib/kaih/model";

export const HABIT_ICONS: Record<HabitKey, LucideIcon> = {
  bangun: Sun,
  ibadah: HeartHandshake,
  olahraga: PersonStanding,
  makan: Utensils,
  belajar: BookOpen,
  masyarakat: Users,
  tidur: Bed,
};

export const TROPHY_ICONS = {
  awal: Footprints,
  tangga: TrendingUp,
  terakhir: Flag,
  pelopor: Star,
} as const;

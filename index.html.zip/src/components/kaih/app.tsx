import { useEffect } from "react";
import { Toaster } from "sonner";
import { useKaih, boot } from "@/lib/kaih/store";
import { LoginScreen } from "@/components/kaih/login";
import { Shell } from "@/components/kaih/shell";
import { HomeView } from "@/components/kaih/home";
import { JurnalView } from "@/components/kaih/jurnal";
import { LencanaView } from "@/components/kaih/lencana";
import { MonitorView } from "@/components/kaih/monitor";

export function KaihApp() {
  const snapshot = useKaih();

  useEffect(() => {
    boot();
  }, []);

  return (
    <>
      <Toaster position="top-center" />
      {!snapshot.ready ? (
        <Splash />
      ) : snapshot.view === "login" ? (
        <LoginScreen />
      ) : snapshot.view === "monitor" ? (
        <MonitorView />
      ) : (
        <Shell>
          {snapshot.view === "home" ? <HomeView /> : null}
          {snapshot.view === "jurnal" ? <JurnalView /> : null}
          {snapshot.view === "lencana" ? <LencanaView /> : null}
        </Shell>
      )}
    </>
  );
}

function Splash() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-kaih-paper text-kaih-ink">
      <img src="/logo-kaih.png" alt="" className="h-20 w-auto object-contain" />
      <p className="text-sm font-semibold text-kaih-muted">Menyiapkan Jurnal KAIH...</p>
    </div>
  );
}

import { useMemo, useState } from "react";
import { LogOut, Search } from "lucide-react";
import { logsFor, type Student } from "@/lib/kaih/model";
import { logout, useKaih } from "@/lib/kaih/store";
import { fieldClass } from "@/components/kaih/ui";

export function MonitorView() {
  const snapshot = useKaih();
  const [query, setQuery] = useState("");
  const [kelas, setKelas] = useState("");
  const classes = useMemo(
    () => Array.from(new Set(snapshot.students.map((student) => student.kelas))).sort(),
    [snapshot.students],
  );
  const rows = snapshot.students
    .filter((student) => {
      const blob = `${student.nama} ${student.nisn} ${student.kelas}`.toLowerCase();
      const matchQuery = blob.includes(query.trim().toLowerCase());
      return matchQuery && (!kelas || student.kelas === kelas);
    })
    .map((student) => summarize(student, snapshot.logs))
    .sort((a, b) => b.points - a.points);

  const totalLogs = snapshot.logs.length;
  const totalPoints = snapshot.logs.reduce((acc, log) => acc + log.totalPoin, 0);

  return (
    <div className="min-h-screen bg-kaih-paper">
      <header className="border-b border-kaih-line bg-kaih-card">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-3">
          <img src="/logo-kaih.png" alt="Logo SMA Negeri 1 Kartasura" className="h-12 w-auto object-contain" />
          <div>
            <p className="text-sm font-extrabold">Pantauan guru</p>
            <p className="text-xs text-kaih-muted">Jurnal KAIH · SMA Negeri 1 Kartasura</p>
          </div>
          <button
            type="button"
            onClick={logout}
            className="ml-auto inline-flex size-11 items-center justify-center rounded-xl text-kaih-muted hover:bg-kaih-soft-amber"
            aria-label="Keluar"
          >
            <LogOut className="size-4" />
          </button>
        </div>
      </header>
      <main className="mx-auto max-w-5xl space-y-4 px-4 py-6">
        <div className="grid gap-3 sm:grid-cols-3">
          <Stat label="Siswa terdaftar" value={String(snapshot.students.length)} />
          <Stat label="Entri jurnal" value={String(totalLogs)} />
          <Stat label="Total poin" value={String(totalPoints)} />
        </div>
        <section className="rounded-2xl border border-kaih-line bg-kaih-card p-4">
          <div className="mb-4 grid gap-3 sm:grid-cols-2">
            <label className="relative block">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-kaih-muted" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Cari nama, NISN, atau kelas"
                className={`${fieldClass} pl-10`}
              />
            </label>
            <select value={kelas} onChange={(event) => setKelas(event.target.value)} className={fieldClass}>
              <option value="">Semua kelas</option>
              {classes.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-xl text-sm">
              <thead className="text-left text-xs text-kaih-muted">
                <tr className="border-b border-kaih-line">
                  <th className="py-2 pr-3">NISN</th>
                  <th className="py-2 pr-3">Nama</th>
                  <th className="py-2 pr-3">Kelas</th>
                  <th className="py-2 pr-3 text-center">Isi jurnal</th>
                  <th className="py-2 text-center">Total poin</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.nisn} className="border-b border-kaih-line last:border-0">
                    <td className="py-2.5 pr-3 tracking-wide">{row.nisn}</td>
                    <td className="py-2.5 pr-3 font-semibold">{row.nama}</td>
                    <td className="py-2.5 pr-3">{row.kelas}</td>
                    <td className="py-2.5 pr-3 text-center">{row.count}</td>
                    <td className="py-2.5 text-center font-bold">{row.points}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}

function summarize(student: Student, logs: ReturnType<typeof useKaih>["logs"]) {
  const mine = logsFor(logs, student.nisn);
  return {
    ...student,
    count: mine.length,
    points: mine.reduce((acc, log) => acc + log.totalPoin, 0),
  };
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-kaih-line bg-kaih-card px-4 py-4">
      <p className="text-2xl font-extrabold">{value}</p>
      <p className="text-xs font-semibold text-kaih-muted">{label}</p>
    </div>
  );
}

import { useState } from "react";
import { toast } from "sonner";
import { CalendarDays, ChevronLeft, ChevronRight, Download, Medal, PenLine } from "lucide-react";
import {
  CartesianGrid,
  Line,
  LineChart,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  BULAN_ID,
  fmtDateShort,
  fmtDayMonth,
  HABITS,
  HARI_ID,
  habitsCompleted,
  habitAveragePercents,
  isoDate,
  logsFor,
  monthKeys,
  monthLabel,
  popularHabit,
  computeStreak,
  scoreMeta,
  todayStr,
  type LogEntry,
  type Student,
} from "@/lib/kaih/model";
import { exportLaporanPdf } from "@/lib/kaih/pdf";
import {
  currentStudent,
  goTodayMonth,
  openJurnal,
  openLencana,
  setLaporanKey,
  shiftMonth,
  useKaih,
} from "@/lib/kaih/store";
import { Button, Card, SectionTitle } from "@/components/kaih/ui";

const toneClass = {
  empty: "border border-kaih-line bg-kaih-card text-kaih-muted",
  good: "bg-kaih-soft-emerald text-kaih-emerald",
  mid: "bg-kaih-soft-amber text-kaih-gold",
  low: "bg-kaih-soft-danger text-kaih-danger",
} as const;

export function HomeView() {
  const snapshot = useKaih();
  const student = currentStudent(snapshot);
  if (!student) return null;
  const mine = logsFor(snapshot.logs, student.nisn);
  return (
    <div className="space-y-8">
      <StudentCard student={student} />
      <ActionRow filledToday={mine.some((log) => log.date === todayStr())} />
      <CalendarBlock
        logs={mine}
        month={snapshot.calMonth}
        year={snapshot.calYear}
      />
      <StatsBlock logs={mine} />
      <ReportBlock
        student={student}
        logs={mine}
        laporanKey={snapshot.laporanKey}
      />
    </div>
  );
}

function StudentCard({ student }: { student: Student }) {
  const items = [
    { label: "Nama", value: student.nama },
    { label: "Kelas", value: student.kelas },
    { label: "NISN", value: student.nisn },
  ];
  return (
    <Card>
      <SectionTitle kicker="Home" title="Data siswa" />
      <dl className="grid gap-3 sm:grid-cols-3">
        {items.map((item) => (
          <div key={item.label} className="rounded-xl bg-kaih-paper px-4 py-3">
            <dt className="text-xs font-semibold text-kaih-muted">{item.label}</dt>
            <dd className="mt-1 text-base font-extrabold break-words text-kaih-ink">{item.value}</dd>
          </div>
        ))}
      </dl>
    </Card>
  );
}

function ActionRow({ filledToday }: { filledToday: boolean }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <button
        type="button"
        onClick={() => openJurnal(todayStr())}
        className="flex min-h-20 items-center gap-3 rounded-2xl bg-kaih-amber px-4 py-4 text-left text-kaih-on"
      >
        <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-kaih-amber-deep">
          <PenLine className="size-5" />
        </span>
        <span>
          <span className="block text-base font-extrabold">Pengisian Jurnal KAIH</span>
          <span className="mt-0.5 block text-sm text-kaih-on">
            {filledToday ? "Hari ini sudah terisi" : "Catat 7 kebiasaan hari ini"}
          </span>
        </span>
      </button>
      <button
        type="button"
        onClick={openLencana}
        className="flex min-h-20 items-center gap-3 rounded-2xl border border-kaih-line bg-kaih-card px-4 py-4 text-left"
      >
        <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-kaih-soft-amber text-kaih-amber">
          <Medal className="size-5" />
        </span>
        <span>
          <span className="block text-base font-extrabold">Lencana & Prestasi</span>
          <span className="mt-0.5 block text-sm text-kaih-muted">Piala dan lencana kebiasaan</span>
        </span>
      </button>
    </div>
  );
}

function CalendarBlock({ logs, month, year }: { logs: LogEntry[]; month: number; year: number }) {
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  const today = todayStr();
  const cells: Array<{ day: number; date: string } | null> = [
    ...Array.from({ length: first }, () => null),
    ...Array.from({ length: days }, (_, index) => {
      const day = index + 1;
      return { day, date: isoDate(new Date(year, month, day)) };
    }),
  ];
  const history = [...logs].sort((a, b) => b.date.localeCompare(a.date));

  return (
    <Card>
      <SectionTitle kicker="Riwayat" title="Kalender dan riwayat pengisian" />
      <div className="mb-4 flex items-center justify-between">
        <button type="button" aria-label="Bulan sebelumnya" onClick={() => shiftMonth(-1)} className="inline-flex size-11 items-center justify-center rounded-full border border-kaih-line">
          <ChevronLeft className="size-4" />
        </button>
        <div className="text-center">
          <p className="font-extrabold">{BULAN_ID[month]} {year}</p>
          <button type="button" onClick={goTodayMonth} className="text-xs font-semibold text-kaih-amber">
            Hari ini
          </button>
        </div>
        <button type="button" aria-label="Bulan berikutnya" onClick={() => shiftMonth(1)} className="inline-flex size-11 items-center justify-center rounded-full border border-kaih-line">
          <ChevronRight className="size-4" />
        </button>
      </div>
      <div className="mb-2 grid grid-cols-7 gap-1.5 text-center text-xs font-bold text-kaih-muted">
        {HARI_ID.map((day) => (
          <div key={day}>{day}</div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1.5">
        {cells.map((cell, index) => {
          if (!cell) return <div key={`empty-${index}`} />;
          const log = logs.find((item) => item.date === cell.date);
          const meta = scoreMeta(log ? log.skorPersen : null);
          const future = cell.date > today;
          return (
            <button
              key={cell.date}
              type="button"
              disabled={future}
              onClick={() => openJurnal(cell.date)}
              className={`flex aspect-square flex-col items-center justify-center rounded-xl text-xs font-bold ${toneClass[meta.tone]} ${cell.date === today ? "ring-2 ring-kaih-amber" : ""} disabled:opacity-40`}
            >
              <span>{cell.day}</span>
            </button>
          );
        })}
      </div>
      <div className="mt-4 flex flex-wrap justify-center gap-3 text-xs font-semibold text-kaih-muted">
        <Legend swatch="bg-kaih-soft-emerald" label="Sangat baik" />
        <Legend swatch="bg-kaih-soft-amber" label="Baik" />
        <Legend swatch="bg-kaih-soft-danger" label="Perlu ditingkatkan" />
        <Legend swatch="border border-kaih-line bg-kaih-card" label="Belum terisi" />
      </div>

      <div className="mt-6 overflow-x-auto">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold">
          <CalendarDays className="size-4 text-kaih-amber" />
          Riwayat log
        </h3>
        <table className="w-full min-w-lg text-sm">
          <thead className="text-left text-xs text-kaih-muted">
            <tr className="border-b border-kaih-line">
              <th className="py-2 font-semibold">Tanggal</th>
              <th className="py-2 text-center font-semibold">Kebiasaan</th>
              <th className="py-2 text-center font-semibold">Skor</th>
              <th className="py-2 text-center font-semibold">Status</th>
            </tr>
          </thead>
          <tbody>
            {history.length ? (
              history.map((log) => {
                const meta = scoreMeta(log.skorPersen);
                return (
                  <tr key={log.id} className="border-b border-kaih-line last:border-0">
                    <td className="py-2.5">
                      <button type="button" className="font-semibold text-kaih-ink" onClick={() => openJurnal(log.date)}>
                        {fmtDateShort(log.date)}
                      </button>
                    </td>
                    <td className="py-2.5 text-center">{habitsCompleted(log)} / 7</td>
                    <td className="py-2.5 text-center font-bold">{log.skorPersen}%</td>
                    <td className="py-2.5 text-center">
                      <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${toneClass[meta.tone]}`}>{meta.label}</span>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={4} className="py-8 text-center text-kaih-muted">
                  Belum ada riwayat jurnal.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function Legend({ swatch, label }: { swatch: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={`size-3 rounded-full ${swatch}`} />
      {label}
    </span>
  );
}

function StatsBlock({ logs }: { logs: LogEntry[] }) {
  const streak = computeStreak(logs);
  const average = logs.length ? Math.round(logs.reduce((acc, log) => acc + log.skorPersen, 0) / logs.length) : 0;
  const averages = habitAveragePercents(logs);
  const radar = HABITS.map((habit, index) => ({ habit: habit.short, capaian: averages[index] }));
  const recent = logs.slice(-14).map((log) => ({ hari: fmtDayMonth(log.date), skor: log.skorPersen }));
  const cards = [
    { label: "Hari beruntun", value: String(streak) },
    { label: "Log terisi", value: String(logs.length) },
    { label: "Rata-rata capaian", value: `${average}%` },
    { label: "Kebiasaan terkuat", value: popularHabit(logs) },
  ];

  return (
    <Card>
      <SectionTitle kicker="Capaian" title="Statistik" />
      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map((card) => (
          <div key={card.label} className="rounded-xl bg-kaih-paper px-3 py-3">
            <p className="text-xl font-extrabold text-kaih-ink">{card.value}</p>
            <p className="mt-1 text-xs font-semibold text-kaih-muted">{card.label}</p>
          </div>
        ))}
      </div>
      {logs.length ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="rounded-xl border border-kaih-line p-3">
            <h3 className="mb-2 text-sm font-bold">Distribusi 7 kebiasaan</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radar} outerRadius="68%">
                  <PolarGrid stroke="var(--color-kaih-line)" />
                  <PolarAngleAxis dataKey="habit" tick={{ fill: "var(--color-kaih-muted)", fontSize: 11 }} />
                  <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar dataKey="capaian" stroke="var(--color-kaih-emerald)" fill="var(--color-kaih-emerald)" fillOpacity={0.25} />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="rounded-xl border border-kaih-line p-3">
            <h3 className="mb-2 text-sm font-bold">Tren skor harian</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={recent}>
                  <CartesianGrid stroke="var(--color-kaih-line)" vertical={false} />
                  <XAxis dataKey="hari" tick={{ fill: "var(--color-kaih-muted)", fontSize: 11 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: "var(--color-kaih-muted)", fontSize: 11 }} width={32} />
                  <Tooltip />
                  <Line type="monotone" dataKey="skor" stroke="var(--color-kaih-amber)" strokeWidth={2} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      ) : (
        <p className="rounded-xl bg-kaih-paper px-4 py-8 text-center text-sm text-kaih-muted">
          Statistik muncul setelah jurnal pertama tersimpan.
        </p>
      )}
    </Card>
  );
}

function ReportBlock({ student, logs, laporanKey }: { student: Student; logs: LogEntry[]; laporanKey: string }) {
  const months = monthKeys(logs);
  const key = months.includes(laporanKey) ? laporanKey : months[0];
  const rows = logs.filter((log) => log.date.startsWith(key));
  const total = rows.reduce((acc, log) => acc + log.totalPoin, 0);
  const average = rows.length ? Math.round(rows.reduce((acc, log) => acc + log.skorPersen, 0) / rows.length) : 0;
  const [busy, setBusy] = useState(false);

  async function download() {
    setBusy(true);
    try {
      await exportLaporanPdf(student, rows, monthLabel(key));
      toast.success("Laporan PDF berhasil diunduh.");
    } catch {
      toast.error("Laporan PDF gagal dibuat. Coba lagi.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <SectionTitle kicker="Rekap" title="Laporan PDF" />
        <div className="flex flex-col gap-2 sm:flex-row">
          <select
            aria-label="Bulan laporan"
            value={key}
            onChange={(event) => setLaporanKey(event.target.value)}
            className="min-h-11 rounded-xl border border-kaih-line bg-kaih-card px-3 text-sm font-semibold"
          >
            {months.map((month) => (
              <option key={month} value={month}>
                {monthLabel(month)}
              </option>
            ))}
          </select>
          <Button onClick={download} disabled={busy}>
            <Download className="size-4" />
            {busy ? "Menyiapkan..." : "Unduh PDF"}
          </Button>
        </div>
      </div>
      <div className="mb-4 grid gap-2 text-sm sm:grid-cols-2">
        <p><span className="text-kaih-muted">Nama</span> · <b>{student.nama}</b></p>
        <p><span className="text-kaih-muted">NISN</span> · <b className="tracking-wide">{student.nisn}</b></p>
        <p><span className="text-kaih-muted">Kelas</span> · <b>{student.kelas}</b></p>
        <p><span className="text-kaih-muted">Rata-rata</span> · <b>{average}%</b> · <b className="text-kaih-gold">{total} poin</b></p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-2xl border-collapse text-xs">
          <thead>
            <tr className="bg-kaih-paper text-kaih-muted">
              <th className="border border-kaih-line px-2 py-2">Tanggal</th>
              {HABITS.map((habit) => (
                <th key={habit.key} className="border border-kaih-line px-2 py-2">{habit.short}</th>
              ))}
              <th className="border border-kaih-line px-2 py-2">Poin</th>
              <th className="border border-kaih-line px-2 py-2">Skor</th>
            </tr>
          </thead>
          <tbody>
            {rows.length ? (
              rows.map((log) => (
                <tr key={log.id}>
                  <td className="border border-kaih-line px-2 py-2 text-center">{fmtDateShort(log.date)}</td>
                  {HABITS.map((habit) => {
                    const sel = log.selections[habit.key];
                    const pts =
                      habit.type === "radio"
                        ? typeof sel === "number"
                          ? habit.options[sel]?.points ?? 0
                          : 0
                        : Array.isArray(sel)
                          ? sel.reduce((acc, idx) => acc + (habit.options[idx]?.points ?? 0), 0)
                          : 0;
                    return (
                      <td key={habit.key} className="border border-kaih-line px-2 py-2 text-center">
                        {pts}
                      </td>
                    );
                  })}
                  <td className="border border-kaih-line px-2 py-2 text-center font-bold">{log.totalPoin}</td>
                  <td className="border border-kaih-line px-2 py-2 text-center font-bold">{log.skorPersen}%</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={HABITS.length + 3} className="border border-kaih-line px-2 py-6 text-center text-kaih-muted">
                  Belum ada jurnal pada periode ini.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="mt-8 grid gap-8 text-center text-sm sm:grid-cols-2">
        <SignLine role="Orang tua / wali" />
        <SignLine role="Guru pembimbing" />
      </div>
    </Card>
  );
}

function SignLine({ role }: { role: string }) {
  return (
    <div>
      <p>{role}</p>
      <div className="h-16" />
      <p className="border-t border-kaih-muted pt-2 text-kaih-muted">(................................)</p>
    </div>
  );
}

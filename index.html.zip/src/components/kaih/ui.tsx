import { clsx } from "clsx";
import type { ButtonHTMLAttributes, ReactNode } from "react";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  tone?: "primary" | "secondary" | "ghost";
};

export function Button({ tone = "primary", className, type = "button", ...props }: ButtonProps) {
  return (
    <button
      type={type}
      className={clsx(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-60",
        tone === "primary" && "bg-kaih-amber text-kaih-on hover:bg-kaih-amber-deep",
        tone === "secondary" && "border border-kaih-line bg-kaih-card text-kaih-ink hover:bg-kaih-soft-amber",
        tone === "ghost" && "text-kaih-muted hover:bg-kaih-soft-amber hover:text-kaih-ink",
        className,
      )}
      {...props}
    />
  );
}

export const fieldClass =
  "min-h-11 w-full rounded-xl border border-kaih-line bg-kaih-card px-3 py-2 text-sm text-kaih-ink outline-none focus:border-kaih-amber";

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <section className={clsx("rounded-2xl border border-kaih-line bg-kaih-card p-4 shadow-sm sm:p-5", className)}>
      {children}
    </section>
  );
}

export function SectionTitle({ kicker, title }: { kicker: string; title: string }) {
  return (
    <div className="mb-4">
      <p className="text-xs font-bold tracking-wide text-kaih-amber uppercase">{kicker}</p>
      <h2 className="mt-1 text-lg font-extrabold text-kaih-ink">{title}</h2>
    </div>
  );
}

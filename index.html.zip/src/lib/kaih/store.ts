import { useSyncExternalStore } from "react";
import {
  buildDemoLogs,
  calcScore,
  DEFAULT_STUDENTS,
  HABITS,
  isValidNisn,
  MONITOR_NISN,
  monthStart,
  todayStr,
  type LogEntry,
  type Mood,
  type Selections,
  type Student,
  moodFor,
  type HabitKey,
} from "@/lib/kaih/model";

export type View = "login" | "home" | "jurnal" | "lencana" | "monitor";

export type Reaction = {
  habit: HabitKey;
  index: number;
  mood: Mood;
  nonce: number;
};

type KaihState = {
  ready: boolean;
  students: Student[];
  logs: LogEntry[];
  currentNisn: string | null;
  view: View;
  jurnalDate: string;
  selections: Selections;
  refleksi: string;
  calMonth: number;
  calYear: number;
  lencanaFrom: string;
  lencanaTo: string;
  laporanKey: string;
  lastReaction: Reaction | null;
  celebrate: number | null;
};

const KEYS = {
  students: "kaih_app_students_v1",
  logs: "kaih_app_logs_v1",
  nisn: "kaih_app_nisn_v1",
};

const now = new Date();

const serverState: KaihState = {
  ready: false,
  students: [],
  logs: [],
  currentNisn: null,
  view: "login",
  jurnalDate: todayStr(),
  selections: {},
  refleksi: "",
  calMonth: now.getMonth(),
  calYear: now.getFullYear(),
  lencanaFrom: monthStart(now),
  lencanaTo: todayStr(),
  laporanKey: todayStr().slice(0, 7),
  lastReaction: null,
  celebrate: null,
};

let state: KaihState = serverState;
const listeners = new Set<() => void>();
let booted = false;

function emit(next: KaihState) {
  state = next;
  listeners.forEach((listener) => listener());
}

function patch(partial: Partial<KaihState>) {
  emit({ ...state, ...partial });
}

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function persist() {
  localStorage.setItem(KEYS.students, JSON.stringify(state.students));
  localStorage.setItem(KEYS.logs, JSON.stringify(state.logs));
  if (state.currentNisn) localStorage.setItem(KEYS.nisn, state.currentNisn);
  else localStorage.removeItem(KEYS.nisn);
}

function findLog(nisn: string | null, date: string) {
  if (!nisn) return undefined;
  return state.logs.find((log) => log.nisn === nisn && log.date === date);
}

export function boot() {
  if (booted) return;
  booted = true;
  const storedStudents = readJson<Student[] | null>(KEYS.students, null);
  const students = storedStudents?.length ? storedStudents : DEFAULT_STUDENTS.map((student) => ({ ...student }));
  const storedLogs = readJson<LogEntry[] | null>(KEYS.logs, null);
  const logs = storedLogs ?? buildDemoLogs();
  const nisn = localStorage.getItem(KEYS.nisn);
  const student = students.find((item) => item.nisn === nisn);
  const isMonitor = nisn === MONITOR_NISN;
  const currentNisn = student || isMonitor ? nisn : null;
  const view: View = isMonitor ? "monitor" : student ? "home" : "login";
  emit({
    ...state,
    ready: true,
    students,
    logs,
    currentNisn,
    view,
    jurnalDate: todayStr(),
    lencanaFrom: monthStart(),
    lencanaTo: todayStr(),
    laporanKey: todayStr().slice(0, 7),
  });
  if (!storedStudents?.length || !storedLogs) persist();
}

export type LoginResult = "ok" | "monitor" | "missing" | "invalid" | "empty";

export function login(raw: string): LoginResult {
  const nisn = raw.trim();
  if (!nisn) return "empty";
  if (!isValidNisn(nisn)) return "invalid";
  if (nisn === MONITOR_NISN) {
    patch({ currentNisn: nisn, view: "monitor" });
    persist();
    return "monitor";
  }
  const student = state.students.find((item) => item.nisn === nisn);
  if (!student) return "missing";
  patch({
    currentNisn: nisn,
    view: "home",
    jurnalDate: todayStr(),
    selections: {},
    refleksi: "",
    lastReaction: null,
    celebrate: null,
  });
  persist();
  return "ok";
}

export function register(input: { nisn: string; nama: string; kelas: string }) {
  const nisn = input.nisn.trim();
  const nama = input.nama.trim();
  if (!isValidNisn(nisn)) return "NISN harus tepat 10 digit angka.";
  if (nama.length < 3) return "Nama lengkap minimal 3 huruf.";
  if (!input.kelas) return "Pilih kelas terlebih dahulu.";
  if (state.students.some((student) => student.nisn === nisn)) {
    return "NISN ini sudah terdaftar. Gunakan menu masuk.";
  }
  const students = [...state.students, { nisn, nama, kelas: input.kelas }];
  patch({
    students,
    currentNisn: nisn,
    view: "home",
    jurnalDate: todayStr(),
    selections: {},
    refleksi: "",
    lastReaction: null,
  });
  persist();
  return null;
}

export function logout() {
  patch({
    currentNisn: null,
    view: "login",
    selections: {},
    refleksi: "",
    lastReaction: null,
    celebrate: null,
  });
  persist();
}

export function goHome() {
  patch({ view: "home" });
}

export function openLencana() {
  patch({ view: "lencana" });
}

export function openJurnal(date?: string) {
  const jurnalDate = date ?? state.jurnalDate;
  const saved = findLog(state.currentNisn, jurnalDate);
  const dateChanged = jurnalDate !== state.jurnalDate;
  patch({
    view: "jurnal",
    jurnalDate,
    selections: saved ? structuredClone(saved.selections) : dateChanged ? {} : state.selections,
    refleksi: saved ? saved.refleksi : dateChanged ? "" : state.refleksi,
    lastReaction: saved || dateChanged ? null : state.lastReaction,
    celebrate: null,
  });
}

export function toggleOption(habitKey: HabitKey, index: number) {
  if (findLog(state.currentNisn, state.jurnalDate)) return { locked: true as const };
  const habit = HABITS.find((item) => item.key === habitKey);
  if (!habit) return { locked: false as const };
  const selections: Selections = { ...state.selections };
  let selected = true;
  if (habit.type === "radio") {
    selections[habitKey] = index;
  } else {
    const current = Array.isArray(selections[habitKey]) ? [...(selections[habitKey] as number[])] : [];
    const pos = current.indexOf(index);
    if (pos >= 0) {
      current.splice(pos, 1);
      selected = false;
    } else {
      current.push(index);
    }
    selections[habitKey] = current;
  }
  const mood = moodFor(index, habit.options.length);
  patch({
    selections,
    lastReaction: selected
      ? { habit: habitKey, index, mood, nonce: Date.now() }
      : state.lastReaction,
  });
  return { locked: false as const, mood: selected ? mood : null };
}

export function setRefleksi(refleksi: string) {
  if (findLog(state.currentNisn, state.jurnalDate)) return;
  patch({ refleksi });
}

export function saveJurnal() {
  const nisn = state.currentNisn;
  if (!nisn) return { ok: false as const, message: "Sesi tidak ditemukan." };
  if (findLog(nisn, state.jurnalDate)) {
    return { ok: false as const, message: "Jurnal tanggal ini sudah diisi dan terkunci." };
  }
  const missing = HABITS.some((habit) => habit.type === "radio" && typeof state.selections[habit.key] !== "number");
  if (missing) return { ok: false as const, message: "Lengkapi seluruh pilihan kebiasaan sebelum menyimpan." };
  if (state.jurnalDate > todayStr()) return { ok: false as const, message: "Tanggal tidak boleh melebihi hari ini." };
  const { total, percent } = calcScore(state.selections);
  const entry: LogEntry = {
    id: `${nisn}-${state.jurnalDate}-${Date.now().toString(36)}`,
    nisn,
    date: state.jurnalDate,
    selections: structuredClone(state.selections),
    totalPoin: total,
    skorPersen: percent,
    refleksi: state.refleksi.trim(),
  };
  patch({
    logs: [...state.logs, entry],
    lastReaction: null,
    celebrate: percent,
  });
  persist();
  return { ok: true as const, message: `Jurnal tersimpan. Skor hari ini ${percent}%.`, percent };
}

export function shiftMonth(delta: number) {
  let month = state.calMonth + delta;
  let year = state.calYear;
  if (month < 0) {
    month = 11;
    year -= 1;
  }
  if (month > 11) {
    month = 0;
    year += 1;
  }
  patch({ calMonth: month, calYear: year });
}

export function goTodayMonth() {
  const date = new Date();
  patch({ calMonth: date.getMonth(), calYear: date.getFullYear() });
}

export function setLencanaRange(from: string, to: string) {
  patch({ lencanaFrom: from, lencanaTo: to });
}

export function setLaporanKey(laporanKey: string) {
  patch({ laporanKey });
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useKaih() {
  return useSyncExternalStore(subscribe, () => state, () => serverState);
}

export function currentStudent(snapshot: KaihState) {
  return snapshot.students.find((student) => student.nisn === snapshot.currentNisn) ?? null;
}

export function jurnalLocked(snapshot: KaihState) {
  return Boolean(findLog(snapshot.currentNisn, snapshot.jurnalDate));
}

import type { LogEntry, Student } from "@/lib/kaih/model";
import { fmtDateShort, HABITS, habitPoints } from "@/lib/kaih/model";

export async function exportLaporanPdf(student: Student, logs: LogEntry[], periodLabel: string) {
  const { jsPDF } = await import("jspdf");
  const { autoTable } = await import("jspdf-autotable");
  const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
  const margin = 32;
  const total = logs.reduce((acc, log) => acc + log.totalPoin, 0);
  const average = logs.length ? Math.round(logs.reduce((acc, log) => acc + log.skorPersen, 0) / logs.length) : 0;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.text("JURNAL KEBIASAAN ANAK INDONESIA HEBAT (KAIH)", margin, 36);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.text(`SMA Negeri 1 Kartasura  ·  Periode ${periodLabel}`, margin, 54);
  doc.text(`Nama: ${student.nama}     NISN: ${student.nisn}     Kelas: ${student.kelas}`, margin, 70);
  doc.text(`Rata-rata capaian: ${average}%     Total poin: ${total}`, margin, 86);

  const head = [["Tanggal", ...HABITS.map((habit) => habit.short), "Poin", "Skor"]];
  const body = logs.map((log) => [
    fmtDateShort(log.date),
    ...HABITS.map((habit) => String(habitPoints(habit, log.selections[habit.key]))),
    String(log.totalPoin),
    `${log.skorPersen}%`,
  ]);

  autoTable(doc, {
    head,
    body: body.length ? body : [["Belum ada isian pada periode ini", ...Array(HABITS.length + 2).fill("—")]],
    startY: 102,
    margin: { left: margin, right: margin },
    styles: { fontSize: 8, cellPadding: 4, valign: "middle" },
    headStyles: { fillColor: [154, 52, 18], textColor: 255, halign: "center" },
    columnStyles: { 0: { halign: "left" } },
  });

  const finalY = (doc as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY ?? 140;
  let y = finalY + 48;
  if (y > doc.internal.pageSize.getHeight() - 70) {
    doc.addPage();
    y = 64;
  }
  doc.setFontSize(10);
  doc.text("Orang Tua / Wali", margin + 20, y);
  doc.text("(................................)", margin, y + 48);
  const right = doc.internal.pageSize.getWidth() - margin - 180;
  doc.text("Guru Pembimbing", right, y);
  doc.text("(................................)", right - 10, y + 48);

  const safeName = student.nama.replace(/[^\w\s-]/g, "").trim().replace(/\s+/g, "-");
  doc.save(`Jurnal-KAIH-${safeName}-${periodLabel.replace(/\s+/g, "-")}.pdf`);
}

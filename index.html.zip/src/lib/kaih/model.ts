export type HabitKey =
  | "bangun"
  | "ibadah"
  | "olahraga"
  | "makan"
  | "belajar"
  | "masyarakat"
  | "tidur";

export type HabitOption = { label: string; points: number };

export type Habit = {
  key: HabitKey;
  title: string;
  short: string;
  type: "radio" | "checkbox";
  max?: number;
  options: HabitOption[];
};

export type Selections = Partial<Record<HabitKey, number | number[]>>;

export type Student = {
  nisn: string;
  nama: string;
  kelas: string;
};

export type LogEntry = {
  id: string;
  nisn: string;
  date: string;
  selections: Selections;
  totalPoin: number;
  skorPersen: number;
  refleksi: string;
};

export type Mood = "smile" | "flat" | "sad";

export const MONITOR_NISN = "1234567890";
export const WA_ADMIN = "6287735073793";

export const MOOD_META: Record<Mood, { emoji: string; line: string }> = {
  smile: { emoji: "😊", line: "Pilihan hebat, pertahankan." },
  flat: { emoji: "😐", line: "Cukup baik, masih bisa naik." },
  sad: { emoji: "😢", line: "Ayo ditingkatkan besok." },
};

export const HABITS: Habit[] = [
  {
    key: "bangun",
    title: "1. Bangun Lebih Awal",
    short: "Bangun",
    type: "radio",
    options: [
      { label: "Sebelum 04:30 WIB", points: 15 },
      { label: "04:30 – 05:30 WIB", points: 12 },
      { label: "Setelah 05:30 WIB", points: 8 },
      { label: "Tidak teratur", points: 2 },
    ],
  },
  {
    key: "ibadah",
    title: "2. Taat Beribadah",
    short: "Ibadah",
    type: "radio",
    options: [
      { label: "Tertib", points: 15 },
      { label: "Kurang tertib", points: 8 },
      { label: "Tidak tertib", points: 5 },
      { label: "Tidak pernah beribadah", points: 0 },
    ],
  },
  {
    key: "olahraga",
    title: "3. Berolahraga",
    short: "Olahraga",
    type: "radio",
    options: [
      { label: "Rutin seminggu 3 kali", points: 15 },
      { label: "Tidak rutin berolahraga", points: 8 },
      { label: "Tidak pernah berolahraga", points: 2 },
    ],
  },
  {
    key: "makan",
    title: "4. Makan Sehat",
    short: "Makan",
    type: "checkbox",
    max: 15,
    options: [
      { label: "Sarapan bergizi", points: 4 },
      { label: "Makan siang sehat", points: 4 },
      { label: "Konsumsi buah atau sayur", points: 4 },
      { label: "Minum air putih cukup 8 gelas", points: 3 },
    ],
  },
  {
    key: "belajar",
    title: "5. Gemar Belajar",
    short: "Belajar",
    type: "radio",
    options: [
      { label: "Belajar lebih dari 1 jam", points: 15 },
      { label: "Belajar 30–60 menit", points: 12 },
      { label: "Belajar kurang dari 30 menit", points: 9 },
      { label: "Tidak belajar mandiri", points: 2 },
    ],
  },
  {
    key: "masyarakat",
    title: "6. Bermasyarakat",
    short: "Sosial",
    type: "radio",
    options: [
      { label: "Rutin kegiatan sosial", points: 15 },
      { label: "Kadang mengikuti", points: 8 },
      { label: "Tidak pernah mengikuti", points: 2 },
    ],
  },
  {
    key: "tidur",
    title: "7. Tidur Cepat",
    short: "Tidur",
    type: "radio",
    options: [
      { label: "Sebelum 21.30", points: 15 },
      { label: "Jam 21.30–24.00", points: 8 },
      { label: "Setelah jam 24.00", points: 3 },
    ],
  },
];

export const MAX_TOTAL_POIN = HABITS.reduce(
  (acc, habit) => acc + (habit.type === "checkbox" ? habit.max ?? 0 : habit.options[0].points),
  0,
);

export const TROPHIES = [
  { key: "awal", label: "Langkah Awal menuju Pelopor", target: 4000 },
  { key: "tangga", label: "Satu Tangga menuju Pelopor", target: 5000 },
  { key: "terakhir", label: "Langkah Terakhir menuju Pelopor", target: 6000 },
  { key: "pelopor", label: "Pelopor Anak Indonesia Hebat", target: 7500 },
] as const;

export const HABIT_BADGE_TARGET = 15;

export const BULAN_ID = [
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember",
];

export const HARI_ID = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];

export function kelasList() {
  const list: string[] = [];
  for (let i = 1; i <= 11; i++) list.push(`X E-${i}`);
  for (let i = 1; i <= 11; i++) list.push(`XI F-${i}`);
  for (let i = 1; i <= 11; i++) list.push(`XII F-${i}`);
  return list;
}

export const KELAS_LIST = kelasList();

export const DEFAULT_STUDENTS: Student[] = [
  { nisn: "0012345001", nama: "Ahmad Fauzan Ramadhan", kelas: "X E-1" },
  { nisn: "0012345002", nama: "Siti Nur Aisyah", kelas: "X E-2" },
  { nisn: "0012345003", nama: "Bima Prasetyo Wibowo", kelas: "XI F-3" },
  { nisn: "0012345004", nama: "Kirana Ayu Lestari", kelas: "XI F-1" },
  { nisn: "0012345005", nama: "Muhammad Rafi Hidayat", kelas: "XII F-5" },
];

export function todayStr() {
  return isoDate(new Date());
}

export function isoDate(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export function monthStart(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-01`;
}

export function shiftDate(dateStr: string, days: number) {
  const [y, m, d] = dateStr.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + days);
  return isoDate(dt);
}

export function fmtDateLong(dateStr: string) {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString("id-ID", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export function fmtDateShort(dateStr: string) {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function fmtDayMonth(dateStr: string) {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "short",
  });
}

export function monthLabel(key: string) {
  const [y, m] = key.split("-").map(Number);
  return `${BULAN_ID[m - 1]} ${y}`;
}

export function isValidNisn(nisn: string) {
  return /^\d{10}$/.test(nisn.trim());
}

export function moodFor(index: number, count: number): Mood {
  if (count <= 1 || index <= 0) return "smile";
  if (index >= count - 1) return "sad";
  return "flat";
}

export type ScoreTone = "empty" | "good" | "mid" | "low";

export function scoreMeta(percent: number | null) {
  if (percent === null) return { label: "Belum terisi", tone: "empty" as ScoreTone };
  if (percent >= 80) return { label: "Sangat Baik", tone: "good" as ScoreTone };
  if (percent >= 50) return { label: "Baik", tone: "mid" as ScoreTone };
  return { label: "Perlu Ditingkatkan", tone: "low" as ScoreTone };
}

export function habitPoints(habit: Habit, sel: number | number[] | undefined) {
  if (habit.type === "radio") {
    return typeof sel === "number" ? habit.options[sel]?.points ?? 0 : 0;
  }
  if (!Array.isArray(sel)) return 0;
  return sel.reduce((acc, idx) => acc + (habit.options[idx]?.points ?? 0), 0);
}

export function calcScore(selections: Selections) {
  const total = HABITS.reduce((acc, habit) => acc + habitPoints(habit, selections[habit.key]), 0);
  const percent = Math.min(100, Math.round((total / MAX_TOTAL_POIN) * 100));
  return { total, percent };
}

export function habitsCompleted(log: LogEntry) {
  return HABITS.reduce((count, habit) => {
    const sel = log.selections[habit.key];
    if (habit.type === "radio") {
      return typeof sel === "number" && habit.options[sel].points > 0 ? count + 1 : count;
    }
    return Array.isArray(sel) && sel.length > 0 ? count + 1 : count;
  }, 0);
}

export function logsFor(logs: LogEntry[], nisn: string) {
  return logs.filter((log) => log.nisn === nisn).sort((a, b) => a.date.localeCompare(b.date));
}

export function computeStreak(sortedLogs: LogEntry[]) {
  if (!sortedLogs.length) return 0;
  const dates = new Set(sortedLogs.map((log) => log.date));
  let cursor = todayStr();
  if (!dates.has(cursor)) cursor = shiftDate(cursor, -1);
  let streak = 0;
  while (dates.has(cursor)) {
    streak += 1;
    cursor = shiftDate(cursor, -1);
  }
  return streak;
}

export function habitAveragePercents(logs: LogEntry[]) {
  return HABITS.map((habit) => {
    if (!logs.length) return 0;
    const maxPts = habit.type === "checkbox" ? habit.max ?? 0 : habit.options[0].points;
    const sum = logs.reduce((acc, log) => acc + habitPoints(habit, log.selections[habit.key]), 0);
    return Math.round((sum / (maxPts * logs.length)) * 100);
  });
}

export function popularHabit(logs: LogEntry[]) {
  if (!logs.length) return "Belum ada";
  const avgs = habitAveragePercents(logs);
  const maxIdx = avgs.indexOf(Math.max(...avgs));
  return HABITS[maxIdx].short;
}

export function monthKeys(logs: LogEntry[]) {
  const keys = Array.from(new Set(logs.map((log) => log.date.slice(0, 7)))).sort().reverse();
  return keys.length ? keys : [todayStr().slice(0, 7)];
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function demoLog(nisn: string, date: string, rand: () => number, refleksi = ""): LogEntry {
  const selections: Selections = {};
  let total = 0;
  for (const habit of HABITS) {
    if (habit.type === "radio") {
      const roll = rand();
      const idx =
        roll < 0.42 ? 0 : roll < 0.72 ? 1 : roll < 0.9 ? Math.min(2, habit.options.length - 1) : habit.options.length - 1;
      selections[habit.key] = idx;
      total += habit.options[idx].points;
    } else {
      const chosen: number[] = [];
      habit.options.forEach((option, idx) => {
        if (rand() > 0.32) {
          chosen.push(idx);
          total += option.points;
        }
      });
      selections[habit.key] = chosen;
    }
  }
  const percent = Math.min(100, Math.round((total / MAX_TOTAL_POIN) * 100));
  return { id: `demo-${nisn}-${date}`, nisn, date, selections, totalPoin: total, skorPersen: percent, refleksi };
}

export function buildDemoLogs(): LogEntry[] {
  const logs: LogEntry[] = [];
  const primary = mulberry32(20261019);
  for (let i = 16; i >= 1; i--) {
    if (i === 3 || i === 9) continue;
    const date = shiftDate(todayStr(), -i);
    logs.push(
      demoLog(
        "0012345001",
        date,
        primary,
        i === 1 ? "Belajar kelompok untuk persiapan ulangan, lalu tidur sebelum jam sepuluh." : "",
      ),
    );
  }
  const secondary = mulberry32(77);
  for (let i = 6; i >= 1; i--) {
    if (i === 2) continue;
    logs.push(demoLog("0012345002", shiftDate(todayStr(), -i), secondary));
  }
  return logs;
}

export function maxPoints(habit: Habit) {
  return habit.type === "checkbox" ? habit.max ?? 0 : habit.options[0].points;
}

export function badgeCount(logs: LogEntry[], habit: Habit) {
  const maxPts = maxPoints(habit);
  return logs.filter((log) => habitPoints(habit, log.selections[habit.key]) === maxPts).length;
}

import { o as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as ChevronLeft, E as Bed, S as ChevronRight, T as BookOpen, _ as House, a as TrendingUp, b as Flag, c as Search, d as PenLine, f as Medal, g as IdCard, h as Lock, l as Save, m as LogIn, n as Users, o as Sun, p as LogOut, r as UserPlus, s as Star, t as Utensils, u as PersonStanding, v as HeartHandshake, w as CalendarDays, x as Download, y as Footprints } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { a as Line, c as PolarAngleAxis, d as ResponsiveContainer, f as Tooltip, i as XAxis, l as PolarRadiusAxis, n as LineChart, o as CartesianGrid, r as YAxis, s as Radar, t as RadarChart, u as PolarGrid } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CrpRNPNA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MONITOR_NISN = "1234567890";
var WA_ADMIN = "6287735073793";
var MOOD_META = {
	smile: {
		emoji: "😊",
		line: "Pilihan hebat, pertahankan."
	},
	flat: {
		emoji: "😐",
		line: "Cukup baik, masih bisa naik."
	},
	sad: {
		emoji: "😢",
		line: "Ayo ditingkatkan besok."
	}
};
var HABITS = [
	{
		key: "bangun",
		title: "1. Bangun Lebih Awal",
		short: "Bangun",
		type: "radio",
		options: [
			{
				label: "Sebelum 04:30 WIB",
				points: 15
			},
			{
				label: "04:30 – 05:30 WIB",
				points: 12
			},
			{
				label: "Setelah 05:30 WIB",
				points: 8
			},
			{
				label: "Tidak teratur",
				points: 2
			}
		]
	},
	{
		key: "ibadah",
		title: "2. Taat Beribadah",
		short: "Ibadah",
		type: "radio",
		options: [
			{
				label: "Tertib",
				points: 15
			},
			{
				label: "Kurang tertib",
				points: 8
			},
			{
				label: "Tidak tertib",
				points: 5
			},
			{
				label: "Tidak pernah beribadah",
				points: 0
			}
		]
	},
	{
		key: "olahraga",
		title: "3. Berolahraga",
		short: "Olahraga",
		type: "radio",
		options: [
			{
				label: "Rutin seminggu 3 kali",
				points: 15
			},
			{
				label: "Tidak rutin berolahraga",
				points: 8
			},
			{
				label: "Tidak pernah berolahraga",
				points: 2
			}
		]
	},
	{
		key: "makan",
		title: "4. Makan Sehat",
		short: "Makan",
		type: "checkbox",
		max: 15,
		options: [
			{
				label: "Sarapan bergizi",
				points: 4
			},
			{
				label: "Makan siang sehat",
				points: 4
			},
			{
				label: "Konsumsi buah atau sayur",
				points: 4
			},
			{
				label: "Minum air putih cukup 8 gelas",
				points: 3
			}
		]
	},
	{
		key: "belajar",
		title: "5. Gemar Belajar",
		short: "Belajar",
		type: "radio",
		options: [
			{
				label: "Belajar lebih dari 1 jam",
				points: 15
			},
			{
				label: "Belajar 30–60 menit",
				points: 12
			},
			{
				label: "Belajar kurang dari 30 menit",
				points: 9
			},
			{
				label: "Tidak belajar mandiri",
				points: 2
			}
		]
	},
	{
		key: "masyarakat",
		title: "6. Bermasyarakat",
		short: "Sosial",
		type: "radio",
		options: [
			{
				label: "Rutin kegiatan sosial",
				points: 15
			},
			{
				label: "Kadang mengikuti",
				points: 8
			},
			{
				label: "Tidak pernah mengikuti",
				points: 2
			}
		]
	},
	{
		key: "tidur",
		title: "7. Tidur Cepat",
		short: "Tidur",
		type: "radio",
		options: [
			{
				label: "Sebelum 21.30",
				points: 15
			},
			{
				label: "Jam 21.30–24.00",
				points: 8
			},
			{
				label: "Setelah jam 24.00",
				points: 3
			}
		]
	}
];
var MAX_TOTAL_POIN = HABITS.reduce((acc, habit) => acc + (habit.type === "checkbox" ? habit.max ?? 0 : habit.options[0].points), 0);
var TROPHIES = [
	{
		key: "awal",
		label: "Langkah Awal menuju Pelopor",
		target: 4e3
	},
	{
		key: "tangga",
		label: "Satu Tangga menuju Pelopor",
		target: 5e3
	},
	{
		key: "terakhir",
		label: "Langkah Terakhir menuju Pelopor",
		target: 6e3
	},
	{
		key: "pelopor",
		label: "Pelopor Anak Indonesia Hebat",
		target: 7500
	}
];
var BULAN_ID = [
	"Januari",
	"Februari",
	"Maret",
	"April",
	"Mei",
	"Juni",
	"Juli",
	"Agustus",
	"September",
	"Oktober",
	"November",
	"Desember"
];
var HARI_ID = [
	"Min",
	"Sen",
	"Sel",
	"Rab",
	"Kam",
	"Jum",
	"Sab"
];
function kelasList() {
	const list = [];
	for (let i = 1; i <= 11; i++) list.push(`X E-${i}`);
	for (let i = 1; i <= 11; i++) list.push(`XI F-${i}`);
	for (let i = 1; i <= 11; i++) list.push(`XII F-${i}`);
	return list;
}
var KELAS_LIST = kelasList();
var DEFAULT_STUDENTS = [
	{
		nisn: "0012345001",
		nama: "Ahmad Fauzan Ramadhan",
		kelas: "X E-1"
	},
	{
		nisn: "0012345002",
		nama: "Siti Nur Aisyah",
		kelas: "X E-2"
	},
	{
		nisn: "0012345003",
		nama: "Bima Prasetyo Wibowo",
		kelas: "XI F-3"
	},
	{
		nisn: "0012345004",
		nama: "Kirana Ayu Lestari",
		kelas: "XI F-1"
	},
	{
		nisn: "0012345005",
		nama: "Muhammad Rafi Hidayat",
		kelas: "XII F-5"
	}
];
function todayStr() {
	return isoDate(/* @__PURE__ */ new Date());
}
function isoDate(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function monthStart(date = /* @__PURE__ */ new Date()) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-01`;
}
function shiftDate(dateStr, days) {
	const [y, m, d] = dateStr.split("-").map(Number);
	const dt = new Date(y, m - 1, d);
	dt.setDate(dt.getDate() + days);
	return isoDate(dt);
}
function fmtDateLong(dateStr) {
	const [y, m, d] = dateStr.split("-").map(Number);
	return new Date(y, m - 1, d).toLocaleDateString("id-ID", {
		weekday: "long",
		day: "numeric",
		month: "long",
		year: "numeric"
	});
}
function fmtDateShort(dateStr) {
	const [y, m, d] = dateStr.split("-").map(Number);
	return new Date(y, m - 1, d).toLocaleDateString("id-ID", {
		day: "numeric",
		month: "short",
		year: "numeric"
	});
}
function fmtDayMonth(dateStr) {
	const [y, m, d] = dateStr.split("-").map(Number);
	return new Date(y, m - 1, d).toLocaleDateString("id-ID", {
		day: "numeric",
		month: "short"
	});
}
function monthLabel(key) {
	const [y, m] = key.split("-").map(Number);
	return `${BULAN_ID[m - 1]} ${y}`;
}
function isValidNisn(nisn) {
	return /^\d{10}$/.test(nisn.trim());
}
function moodFor(index, count) {
	if (count <= 1 || index <= 0) return "smile";
	if (index >= count - 1) return "sad";
	return "flat";
}
function scoreMeta(percent) {
	if (percent === null) return {
		label: "Belum terisi",
		tone: "empty"
	};
	if (percent >= 80) return {
		label: "Sangat Baik",
		tone: "good"
	};
	if (percent >= 50) return {
		label: "Baik",
		tone: "mid"
	};
	return {
		label: "Perlu Ditingkatkan",
		tone: "low"
	};
}
function habitPoints(habit, sel) {
	if (habit.type === "radio") return typeof sel === "number" ? habit.options[sel]?.points ?? 0 : 0;
	if (!Array.isArray(sel)) return 0;
	return sel.reduce((acc, idx) => acc + (habit.options[idx]?.points ?? 0), 0);
}
function calcScore(selections) {
	const total = HABITS.reduce((acc, habit) => acc + habitPoints(habit, selections[habit.key]), 0);
	return {
		total,
		percent: Math.min(100, Math.round(total / MAX_TOTAL_POIN * 100))
	};
}
function habitsCompleted(log) {
	return HABITS.reduce((count, habit) => {
		const sel = log.selections[habit.key];
		if (habit.type === "radio") return typeof sel === "number" && habit.options[sel].points > 0 ? count + 1 : count;
		return Array.isArray(sel) && sel.length > 0 ? count + 1 : count;
	}, 0);
}
function logsFor(logs, nisn) {
	return logs.filter((log) => log.nisn === nisn).sort((a, b) => a.date.localeCompare(b.date));
}
function computeStreak(sortedLogs) {
	if (!sortedLogs.length) return 0;
	const dates = new Set(sortedLogs.map((log) => log.date));
	let cursor = todayStr();
	if (!dates.has(cursor)) cursor = shiftDate(cursor, -1);
	let streak = 0;
	while (dates.has(cursor)) {
		streak += 1;
		cursor = shiftDate(cursor, -1);
	}
	return streak;
}
function habitAveragePercents(logs) {
	return HABITS.map((habit) => {
		if (!logs.length) return 0;
		const maxPts = habit.type === "checkbox" ? habit.max ?? 0 : habit.options[0].points;
		const sum = logs.reduce((acc, log) => acc + habitPoints(habit, log.selections[habit.key]), 0);
		return Math.round(sum / (maxPts * logs.length) * 100);
	});
}
function popularHabit(logs) {
	if (!logs.length) return "Belum ada";
	const avgs = habitAveragePercents(logs);
	return HABITS[avgs.indexOf(Math.max(...avgs))].short;
}
function monthKeys(logs) {
	const keys = Array.from(new Set(logs.map((log) => log.date.slice(0, 7)))).sort().reverse();
	return keys.length ? keys : [todayStr().slice(0, 7)];
}
function mulberry32(seed) {
	let a = seed;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function demoLog(nisn, date, rand, refleksi = "") {
	const selections = {};
	let total = 0;
	for (const habit of HABITS) if (habit.type === "radio") {
		const roll = rand();
		const idx = roll < .42 ? 0 : roll < .72 ? 1 : roll < .9 ? Math.min(2, habit.options.length - 1) : habit.options.length - 1;
		selections[habit.key] = idx;
		total += habit.options[idx].points;
	} else {
		const chosen = [];
		habit.options.forEach((option, idx) => {
			if (rand() > .32) {
				chosen.push(idx);
				total += option.points;
			}
		});
		selections[habit.key] = chosen;
	}
	const percent = Math.min(100, Math.round(total / MAX_TOTAL_POIN * 100));
	return {
		id: `demo-${nisn}-${date}`,
		nisn,
		date,
		selections,
		totalPoin: total,
		skorPersen: percent,
		refleksi
	};
}
function buildDemoLogs() {
	const logs = [];
	const primary = mulberry32(20261019);
	for (let i = 16; i >= 1; i--) {
		if (i === 3 || i === 9) continue;
		const date = shiftDate(todayStr(), -i);
		logs.push(demoLog("0012345001", date, primary, i === 1 ? "Belajar kelompok untuk persiapan ulangan, lalu tidur sebelum jam sepuluh." : ""));
	}
	const secondary = mulberry32(77);
	for (let i = 6; i >= 1; i--) {
		if (i === 2) continue;
		logs.push(demoLog("0012345002", shiftDate(todayStr(), -i), secondary));
	}
	return logs;
}
function maxPoints(habit) {
	return habit.type === "checkbox" ? habit.max ?? 0 : habit.options[0].points;
}
function badgeCount(logs, habit) {
	const maxPts = maxPoints(habit);
	return logs.filter((log) => habitPoints(habit, log.selections[habit.key]) === maxPts).length;
}
var KEYS = {
	students: "kaih_app_students_v1",
	logs: "kaih_app_logs_v1",
	nisn: "kaih_app_nisn_v1"
};
var now = /* @__PURE__ */ new Date();
var serverState = {
	ready: false,
	students: [],
	logs: [],
	currentNisn: null,
	view: "login",
	jurnalDate: todayStr(),
	selections: {},
	refleksi: "",
	calMonth: now.getMonth(),
	calYear: now.getFullYear(),
	lencanaFrom: monthStart(now),
	lencanaTo: todayStr(),
	laporanKey: todayStr().slice(0, 7),
	lastReaction: null,
	celebrate: null
};
var state = serverState;
var listeners = /* @__PURE__ */ new Set();
var booted = false;
function emit(next) {
	state = next;
	listeners.forEach((listener) => listener());
}
function patch(partial) {
	emit({
		...state,
		...partial
	});
}
function readJson(key, fallback) {
	try {
		const raw = localStorage.getItem(key);
		if (!raw) return fallback;
		return JSON.parse(raw);
	} catch {
		return fallback;
	}
}
function persist() {
	localStorage.setItem(KEYS.students, JSON.stringify(state.students));
	localStorage.setItem(KEYS.logs, JSON.stringify(state.logs));
	if (state.currentNisn) localStorage.setItem(KEYS.nisn, state.currentNisn);
	else localStorage.removeItem(KEYS.nisn);
}
function findLog(nisn, date) {
	if (!nisn) return void 0;
	return state.logs.find((log) => log.nisn === nisn && log.date === date);
}
function boot() {
	if (booted) return;
	booted = true;
	const storedStudents = readJson(KEYS.students, null);
	const students = storedStudents?.length ? storedStudents : DEFAULT_STUDENTS.map((student) => ({ ...student }));
	const storedLogs = readJson(KEYS.logs, null);
	const logs = storedLogs ?? buildDemoLogs();
	const nisn = localStorage.getItem(KEYS.nisn);
	const student = students.find((item) => item.nisn === nisn);
	const isMonitor = nisn === MONITOR_NISN;
	const currentNisn = student || isMonitor ? nisn : null;
	const view = isMonitor ? "monitor" : student ? "home" : "login";
	emit({
		...state,
		ready: true,
		students,
		logs,
		currentNisn,
		view,
		jurnalDate: todayStr(),
		lencanaFrom: monthStart(),
		lencanaTo: todayStr(),
		laporanKey: todayStr().slice(0, 7)
	});
	if (!storedStudents?.length || !storedLogs) persist();
}
function login(raw) {
	const nisn = raw.trim();
	if (!nisn) return "empty";
	if (!isValidNisn(nisn)) return "invalid";
	if (nisn === "1234567890") {
		patch({
			currentNisn: nisn,
			view: "monitor"
		});
		persist();
		return "monitor";
	}
	if (!state.students.find((item) => item.nisn === nisn)) return "missing";
	patch({
		currentNisn: nisn,
		view: "home",
		jurnalDate: todayStr(),
		selections: {},
		refleksi: "",
		lastReaction: null,
		celebrate: null
	});
	persist();
	return "ok";
}
function register(input) {
	const nisn = input.nisn.trim();
	const nama = input.nama.trim();
	if (!isValidNisn(nisn)) return "NISN harus tepat 10 digit angka.";
	if (nama.length < 3) return "Nama lengkap minimal 3 huruf.";
	if (!input.kelas) return "Pilih kelas terlebih dahulu.";
	if (state.students.some((student) => student.nisn === nisn)) return "NISN ini sudah terdaftar. Gunakan menu masuk.";
	patch({
		students: [...state.students, {
			nisn,
			nama,
			kelas: input.kelas
		}],
		currentNisn: nisn,
		view: "home",
		jurnalDate: todayStr(),
		selections: {},
		refleksi: "",
		lastReaction: null
	});
	persist();
	return null;
}
function logout() {
	patch({
		currentNisn: null,
		view: "login",
		selections: {},
		refleksi: "",
		lastReaction: null,
		celebrate: null
	});
	persist();
}
function goHome() {
	patch({ view: "home" });
}
function openLencana() {
	patch({ view: "lencana" });
}
function openJurnal(date) {
	const jurnalDate = date ?? state.jurnalDate;
	const saved = findLog(state.currentNisn, jurnalDate);
	const dateChanged = jurnalDate !== state.jurnalDate;
	patch({
		view: "jurnal",
		jurnalDate,
		selections: saved ? structuredClone(saved.selections) : dateChanged ? {} : state.selections,
		refleksi: saved ? saved.refleksi : dateChanged ? "" : state.refleksi,
		lastReaction: saved || dateChanged ? null : state.lastReaction,
		celebrate: null
	});
}
function toggleOption(habitKey, index) {
	if (findLog(state.currentNisn, state.jurnalDate)) return { locked: true };
	const habit = HABITS.find((item) => item.key === habitKey);
	if (!habit) return { locked: false };
	const selections = { ...state.selections };
	let selected = true;
	if (habit.type === "radio") selections[habitKey] = index;
	else {
		const current = Array.isArray(selections[habitKey]) ? [...selections[habitKey]] : [];
		const pos = current.indexOf(index);
		if (pos >= 0) {
			current.splice(pos, 1);
			selected = false;
		} else current.push(index);
		selections[habitKey] = current;
	}
	const mood = moodFor(index, habit.options.length);
	patch({
		selections,
		lastReaction: selected ? {
			habit: habitKey,
			index,
			mood,
			nonce: Date.now()
		} : state.lastReaction
	});
	return {
		locked: false,
		mood: selected ? mood : null
	};
}
function setRefleksi(refleksi) {
	if (findLog(state.currentNisn, state.jurnalDate)) return;
	patch({ refleksi });
}
function saveJurnal() {
	const nisn = state.currentNisn;
	if (!nisn) return {
		ok: false,
		message: "Sesi tidak ditemukan."
	};
	if (findLog(nisn, state.jurnalDate)) return {
		ok: false,
		message: "Jurnal tanggal ini sudah diisi dan terkunci."
	};
	if (HABITS.some((habit) => habit.type === "radio" && typeof state.selections[habit.key] !== "number")) return {
		ok: false,
		message: "Lengkapi seluruh pilihan kebiasaan sebelum menyimpan."
	};
	if (state.jurnalDate > todayStr()) return {
		ok: false,
		message: "Tanggal tidak boleh melebihi hari ini."
	};
	const { total, percent } = calcScore(state.selections);
	const entry = {
		id: `${nisn}-${state.jurnalDate}-${Date.now().toString(36)}`,
		nisn,
		date: state.jurnalDate,
		selections: structuredClone(state.selections),
		totalPoin: total,
		skorPersen: percent,
		refleksi: state.refleksi.trim()
	};
	patch({
		logs: [...state.logs, entry],
		lastReaction: null,
		celebrate: percent
	});
	persist();
	return {
		ok: true,
		message: `Jurnal tersimpan. Skor hari ini ${percent}%.`,
		percent
	};
}
function shiftMonth(delta) {
	let month = state.calMonth + delta;
	let year = state.calYear;
	if (month < 0) {
		month = 11;
		year -= 1;
	}
	if (month > 11) {
		month = 0;
		year += 1;
	}
	patch({
		calMonth: month,
		calYear: year
	});
}
function goTodayMonth() {
	const date = /* @__PURE__ */ new Date();
	patch({
		calMonth: date.getMonth(),
		calYear: date.getFullYear()
	});
}
function setLencanaRange(from, to) {
	patch({
		lencanaFrom: from,
		lencanaTo: to
	});
}
function setLaporanKey(laporanKey) {
	patch({ laporanKey });
}
function subscribe(listener) {
	listeners.add(listener);
	return () => listeners.delete(listener);
}
function useKaih() {
	return (0, import_react.useSyncExternalStore)(subscribe, () => state, () => serverState);
}
function currentStudent(snapshot) {
	return snapshot.students.find((student) => student.nisn === snapshot.currentNisn) ?? null;
}
function jurnalLocked(snapshot) {
	return Boolean(findLog(snapshot.currentNisn, snapshot.jurnalDate));
}
function Button({ tone = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: clsx("inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-60", tone === "primary" && "bg-kaih-amber text-kaih-on hover:bg-kaih-amber-deep", tone === "secondary" && "border border-kaih-line bg-kaih-card text-kaih-ink hover:bg-kaih-soft-amber", tone === "ghost" && "text-kaih-muted hover:bg-kaih-soft-amber hover:text-kaih-ink", className),
		...props
	});
}
var fieldClass = "min-h-11 w-full rounded-xl border border-kaih-line bg-kaih-card px-3 py-2 text-sm text-kaih-ink outline-none focus:border-kaih-amber";
function Card({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: clsx("rounded-2xl border border-kaih-line bg-kaih-card p-4 shadow-sm sm:p-5", className),
		children
	});
}
function SectionTitle({ kicker, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-bold tracking-wide text-kaih-amber uppercase",
			children: kicker
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-1 text-lg font-extrabold text-kaih-ink",
			children: title
		})]
	});
}
function LoginScreen() {
	const [mode, setMode] = (0, import_react.useState)("masuk");
	const [nisn, setNisn] = (0, import_react.useState)("");
	const [nama, setNama] = (0, import_react.useState)("");
	const [kelas, setKelas] = (0, import_react.useState)(KELAS_LIST[0]);
	const [notice, setNotice] = (0, import_react.useState)("");
	function onNisn(value) {
		setNisn(value.replace(/\D/g, "").slice(0, 10));
	}
	function submitLogin(value = nisn) {
		const result = login(value);
		if (result === "ok" || result === "monitor") return;
		if (result === "empty") {
			toast.error("Masukkan NISN terlebih dahulu.");
			return;
		}
		if (result === "invalid") {
			toast.error("NISN harus 10 digit angka.");
			return;
		}
		setMode("daftar");
		setNotice("NISN belum terdaftar. Lengkapi data di bawah, lalu kamu langsung masuk ke Home.");
	}
	function submitRegister() {
		const error = register({
			nisn,
			nama,
			kelas
		});
		if (error) {
			toast.error(error);
			return;
		}
		toast.success("Pendaftaran berhasil. Selamat datang di Home.");
	}
	const help = `https://wa.me/${WA_ADMIN}?text=${encodeURIComponent("Halo Admin, saya membutuhkan bantuan terkait Jurnal KAIH.")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-kaih-paper px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex flex-col items-center text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/logo-kaih.png",
							alt: "Logo SMA Negeri 1 Kartasura",
							className: "mb-3 h-28 w-auto object-contain"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-extrabold text-kaih-ink",
							children: "Jurnal KAIH"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-kaih-muted",
							children: "Kebiasaan Anak Indonesia Hebat · SMA Negeri 1 Kartasura"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-kaih-line bg-kaih-card p-6 shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-5 grid grid-cols-2 gap-2 rounded-xl bg-kaih-paper p-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `min-h-11 rounded-lg text-sm font-bold ${mode === "masuk" ? "bg-kaih-card text-kaih-ink shadow-sm" : "text-kaih-muted"}`,
								onClick: () => {
									setMode("masuk");
									setNotice("");
								},
								children: "Masuk"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `min-h-11 rounded-lg text-sm font-bold ${mode === "daftar" ? "bg-kaih-card text-kaih-ink shadow-sm" : "text-kaih-muted"}`,
								onClick: () => setMode("daftar"),
								children: "Daftar"
							})]
						}),
						notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-4 rounded-xl bg-kaih-soft-amber px-3 py-2 text-sm text-kaih-gold",
							children: notice
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mb-2 block text-sm font-semibold text-kaih-ink",
							htmlFor: "nisn",
							children: "NISN"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdCard, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-kaih-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "nisn",
								inputMode: "numeric",
								autoComplete: "username",
								maxLength: 10,
								placeholder: "10 digit NISN",
								value: nisn,
								onChange: (event) => onNisn(event.target.value),
								onKeyDown: (event) => {
									if (event.key === "Enter" && mode === "masuk") submitLogin();
								},
								className: `${fieldClass} pl-10 tracking-widest`
							})]
						}),
						mode === "daftar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-2 block text-sm font-semibold",
									htmlFor: "nama",
									children: "Nama lengkap"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "nama",
									value: nama,
									onChange: (event) => setNama(event.target.value),
									className: fieldClass
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-2 block text-sm font-semibold",
									htmlFor: "kelas",
									children: "Kelas"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									id: "kelas",
									value: kelas,
									onChange: (event) => setKelas(event.target.value),
									className: fieldClass,
									children: KELAS_LIST.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: item,
										children: item
									}, item))
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									className: "mt-2 w-full",
									onClick: submitRegister,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-4" }), "Daftar dan masuk Home"]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "mt-5 w-full",
							onClick: () => submitLogin(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "size-4" }), "Masuk ke Home"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col items-center gap-2 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 text-sm font-semibold text-kaih-amber",
						onClick: () => {
							setNisn("0012345001");
							setMode("masuk");
							submitLogin("0012345001");
						},
						children: "Coba data contoh · Ahmad Fauzan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-kaih-muted",
						children: [
							"Pantauan guru memakai NISN ",
							MONITOR_NISN,
							".",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "font-semibold text-kaih-emerald",
								href: help,
								target: "_blank",
								rel: "noreferrer",
								children: "Bantuan WhatsApp"
							})
						]
					})]
				})
			]
		})
	});
}
function Shell({ children }) {
	const snapshot = useKaih();
	const student = currentStudent(snapshot);
	if (!student) return null;
	const home = snapshot.view === "home";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-kaih-paper text-kaih-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-30 border-b border-kaih-line bg-kaih-card/95 backdrop-blur",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-5xl items-center gap-2 px-4 py-2.5 sm:gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/logo-kaih.png",
						alt: "Logo SMA Negeri 1 Kartasura",
						className: "h-12 w-auto shrink-0 object-contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: goHome,
						className: clsx("inline-flex min-h-11 items-center gap-2 rounded-full px-4 text-sm font-bold", home ? "bg-kaih-amber text-kaih-on" : "text-kaih-ink hover:bg-kaih-soft-amber"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "size-4" }), "Home"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-sm font-extrabold text-kaih-ink sm:block",
						children: "Jurnal KAIH"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden text-right leading-tight sm:block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "max-w-40 truncate text-sm font-bold",
									children: student.nama
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-kaih-muted",
									children: student.kelas
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex size-11 items-center justify-center rounded-full bg-kaih-soft-amber text-sm font-extrabold text-kaih-amber",
								children: student.nama.trim().charAt(0).toUpperCase()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: logout,
								"aria-label": "Keluar",
								title: "Keluar",
								className: "inline-flex size-11 items-center justify-center rounded-xl text-kaih-muted hover:bg-kaih-soft-amber hover:text-kaih-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" })
							})
						]
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto max-w-5xl px-4 py-6",
			children
		})]
	});
}
async function exportLaporanPdf(student, logs, periodLabel) {
	const { jsPDF } = await import("../_libs/jspdf.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
	const { autoTable } = await import("../_libs/jspdf-autotable.mjs").then((n) => n.t);
	const doc = new jsPDF({
		orientation: "landscape",
		unit: "pt",
		format: "a4"
	});
	const margin = 32;
	const total = logs.reduce((acc, log) => acc + log.totalPoin, 0);
	const average = logs.length ? Math.round(logs.reduce((acc, log) => acc + log.skorPersen, 0) / logs.length) : 0;
	doc.setFont("helvetica", "bold");
	doc.setFontSize(14);
	doc.text("JURNAL KEBIASAAN ANAK INDONESIA HEBAT (KAIH)", margin, 36);
	doc.setFont("helvetica", "normal");
	doc.setFontSize(10);
	doc.text(`SMA Negeri 1 Kartasura  ·  Periode ${periodLabel}`, margin, 54);
	doc.text(`Nama: ${student.nama}     NISN: ${student.nisn}     Kelas: ${student.kelas}`, margin, 70);
	doc.text(`Rata-rata capaian: ${average}%     Total poin: ${total}`, margin, 86);
	const head = [[
		"Tanggal",
		...HABITS.map((habit) => habit.short),
		"Poin",
		"Skor"
	]];
	const body = logs.map((log) => [
		fmtDateShort(log.date),
		...HABITS.map((habit) => String(habitPoints(habit, log.selections[habit.key]))),
		String(log.totalPoin),
		`${log.skorPersen}%`
	]);
	autoTable(doc, {
		head,
		body: body.length ? body : [["Belum ada isian pada periode ini", ...Array(HABITS.length + 2).fill("—")]],
		startY: 102,
		margin: {
			left: margin,
			right: margin
		},
		styles: {
			fontSize: 8,
			cellPadding: 4,
			valign: "middle"
		},
		headStyles: {
			fillColor: [
				154,
				52,
				18
			],
			textColor: 255,
			halign: "center"
		},
		columnStyles: { 0: { halign: "left" } }
	});
	let y = (doc.lastAutoTable?.finalY ?? 140) + 48;
	if (y > doc.internal.pageSize.getHeight() - 70) {
		doc.addPage();
		y = 64;
	}
	doc.setFontSize(10);
	doc.text("Orang Tua / Wali", 52, y);
	doc.text("(................................)", margin, y + 48);
	const right = doc.internal.pageSize.getWidth() - margin - 180;
	doc.text("Guru Pembimbing", right, y);
	doc.text("(................................)", right - 10, y + 48);
	const safeName = student.nama.replace(/[^\w\s-]/g, "").trim().replace(/\s+/g, "-");
	doc.save(`Jurnal-KAIH-${safeName}-${periodLabel.replace(/\s+/g, "-")}.pdf`);
}
var toneClass = {
	empty: "border border-kaih-line bg-kaih-card text-kaih-muted",
	good: "bg-kaih-soft-emerald text-kaih-emerald",
	mid: "bg-kaih-soft-amber text-kaih-gold",
	low: "bg-kaih-soft-danger text-kaih-danger"
};
function HomeView() {
	const snapshot = useKaih();
	const student = currentStudent(snapshot);
	if (!student) return null;
	const mine = logsFor(snapshot.logs, student.nisn);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudentCard, { student }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, { filledToday: mine.some((log) => log.date === todayStr()) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarBlock, {
				logs: mine,
				month: snapshot.calMonth,
				year: snapshot.calYear
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsBlock, { logs: mine }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportBlock, {
				student,
				logs: mine,
				laporanKey: snapshot.laporanKey
			})
		]
	});
}
function StudentCard({ student }) {
	const items = [
		{
			label: "Nama",
			value: student.nama
		},
		{
			label: "Kelas",
			value: student.kelas
		},
		{
			label: "NISN",
			value: student.nisn
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
		kicker: "Home",
		title: "Data siswa"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
		className: "grid gap-3 sm:grid-cols-3",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-kaih-paper px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
				className: "text-xs font-semibold text-kaih-muted",
				children: item.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
				className: "mt-1 text-base font-extrabold break-words text-kaih-ink",
				children: item.value
			})]
		}, item.label))
	})] });
}
function ActionRow({ filledToday }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 sm:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => openJurnal(todayStr()),
			className: "flex min-h-20 items-center gap-3 rounded-2xl bg-kaih-amber px-4 py-4 text-left text-kaih-on",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-11 shrink-0 items-center justify-center rounded-xl bg-kaih-amber-deep",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-base font-extrabold",
				children: "Pengisian Jurnal KAIH"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block text-sm text-kaih-on",
				children: filledToday ? "Hari ini sudah terisi" : "Catat 7 kebiasaan hari ini"
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: openLencana,
			className: "flex min-h-20 items-center gap-3 rounded-2xl border border-kaih-line bg-kaih-card px-4 py-4 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-11 shrink-0 items-center justify-center rounded-xl bg-kaih-soft-amber text-kaih-amber",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Medal, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-base font-extrabold",
				children: "Lencana & Prestasi"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block text-sm text-kaih-muted",
				children: "Piala dan lencana kebiasaan"
			})] })]
		})]
	});
}
function CalendarBlock({ logs, month, year }) {
	const first = new Date(year, month, 1).getDay();
	const days = new Date(year, month + 1, 0).getDate();
	const today = todayStr();
	const cells = [...Array.from({ length: first }, () => null), ...Array.from({ length: days }, (_, index) => {
		const day = index + 1;
		return {
			day,
			date: isoDate(new Date(year, month, day))
		};
	})];
	const history = [...logs].sort((a, b) => b.date.localeCompare(a.date));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			kicker: "Riwayat",
			title: "Kalender dan riwayat pengisian"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Bulan sebelumnya",
					onClick: () => shiftMonth(-1),
					className: "inline-flex size-11 items-center justify-center rounded-full border border-kaih-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-extrabold",
						children: [
							BULAN_ID[month],
							" ",
							year
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: goTodayMonth,
						className: "text-xs font-semibold text-kaih-amber",
						children: "Hari ini"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Bulan berikutnya",
					onClick: () => shiftMonth(1),
					className: "inline-flex size-11 items-center justify-center rounded-full border border-kaih-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-2 grid grid-cols-7 gap-1.5 text-center text-xs font-bold text-kaih-muted",
			children: HARI_ID.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: day }, day))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-7 gap-1.5",
			children: cells.map((cell, index) => {
				if (!cell) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}, `empty-${index}`);
				const log = logs.find((item) => item.date === cell.date);
				const meta = scoreMeta(log ? log.skorPersen : null);
				const future = cell.date > today;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: future,
					onClick: () => openJurnal(cell.date),
					className: `flex aspect-square flex-col items-center justify-center rounded-xl text-xs font-bold ${toneClass[meta.tone]} ${cell.date === today ? "ring-2 ring-kaih-amber" : ""} disabled:opacity-40`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: cell.day })
				}, cell.date);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-wrap justify-center gap-3 text-xs font-semibold text-kaih-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
					swatch: "bg-kaih-soft-emerald",
					label: "Sangat baik"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
					swatch: "bg-kaih-soft-amber",
					label: "Baik"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
					swatch: "bg-kaih-soft-danger",
					label: "Perlu ditingkatkan"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
					swatch: "border border-kaih-line bg-kaih-card",
					label: "Belum terisi"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 overflow-x-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				className: "mb-3 flex items-center gap-2 text-sm font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-4 text-kaih-amber" }), "Riwayat log"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-lg text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-left text-xs text-kaih-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-kaih-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-semibold",
								children: "Tanggal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-center font-semibold",
								children: "Kebiasaan"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-center font-semibold",
								children: "Skor"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-center font-semibold",
								children: "Status"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: history.length ? history.map((log) => {
					const meta = scoreMeta(log.skorPersen);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-kaih-line last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "font-semibold text-kaih-ink",
									onClick: () => openJurnal(log.date),
									children: fmtDateShort(log.date)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2.5 text-center",
								children: [habitsCompleted(log), " / 7"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2.5 text-center font-bold",
								children: [log.skorPersen, "%"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2.5 text-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-2.5 py-1 text-xs font-bold ${toneClass[meta.tone]}`,
									children: meta.label
								})
							})
						]
					}, log.id);
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 4,
					className: "py-8 text-center text-kaih-muted",
					children: "Belum ada riwayat jurnal."
				}) }) })]
			})]
		})
	] });
}
function Legend({ swatch, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-3 rounded-full ${swatch}` }), label]
	});
}
function StatsBlock({ logs }) {
	const streak = computeStreak(logs);
	const average = logs.length ? Math.round(logs.reduce((acc, log) => acc + log.skorPersen, 0) / logs.length) : 0;
	const averages = habitAveragePercents(logs);
	const radar = HABITS.map((habit, index) => ({
		habit: habit.short,
		capaian: averages[index]
	}));
	const recent = logs.slice(-14).map((log) => ({
		hari: fmtDayMonth(log.date),
		skor: log.skorPersen
	}));
	const cards = [
		{
			label: "Hari beruntun",
			value: String(streak)
		},
		{
			label: "Log terisi",
			value: String(logs.length)
		},
		{
			label: "Rata-rata capaian",
			value: `${average}%`
		},
		{
			label: "Kebiasaan terkuat",
			value: popularHabit(logs)
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			kicker: "Capaian",
			title: "Statistik"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-kaih-paper px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xl font-extrabold text-kaih-ink",
					children: card.value
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs font-semibold text-kaih-muted",
					children: card.label
				})]
			}, card.label))
		}),
		logs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-kaih-line p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm font-bold",
					children: "Distribusi 7 kebiasaan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-64",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
							data: radar,
							outerRadius: "68%",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: "var(--color-kaih-line)" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
									dataKey: "habit",
									tick: {
										fill: "var(--color-kaih-muted)",
										fontSize: 11
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
									domain: [0, 100],
									tick: false,
									axisLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
									dataKey: "capaian",
									stroke: "var(--color-kaih-emerald)",
									fill: "var(--color-kaih-emerald)",
									fillOpacity: .25
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {})
							]
						})
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-kaih-line p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm font-bold",
					children: "Tren skor harian"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-64",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
							data: recent,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									stroke: "var(--color-kaih-line)",
									vertical: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "hari",
									tick: {
										fill: "var(--color-kaih-muted)",
										fontSize: 11
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									domain: [0, 100],
									tick: {
										fill: "var(--color-kaih-muted)",
										fontSize: 11
									},
									width: 32
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: "skor",
									stroke: "var(--color-kaih-amber)",
									strokeWidth: 2,
									dot: { r: 3 }
								})
							]
						})
					})
				})]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-xl bg-kaih-paper px-4 py-8 text-center text-sm text-kaih-muted",
			children: "Statistik muncul setelah jurnal pertama tersimpan."
		})
	] });
}
function ReportBlock({ student, logs, laporanKey }) {
	const months = monthKeys(logs);
	const key = months.includes(laporanKey) ? laporanKey : months[0];
	const rows = logs.filter((log) => log.date.startsWith(key));
	const total = rows.reduce((acc, log) => acc + log.totalPoin, 0);
	const average = rows.length ? Math.round(rows.reduce((acc, log) => acc + log.skorPersen, 0) / rows.length) : 0;
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function download() {
		setBusy(true);
		try {
			await exportLaporanPdf(student, rows, monthLabel(key));
			toast.success("Laporan PDF berhasil diunduh.");
		} catch {
			toast.error("Laporan PDF gagal dibuat. Coba lagi.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				kicker: "Rekap",
				title: "Laporan PDF"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					"aria-label": "Bulan laporan",
					value: key,
					onChange: (event) => setLaporanKey(event.target.value),
					className: "min-h-11 rounded-xl border border-kaih-line bg-kaih-card px-3 text-sm font-semibold",
					children: months.map((month) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: month,
						children: monthLabel(month)
					}, month))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: download,
					disabled: busy,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), busy ? "Menyiapkan..." : "Unduh PDF"]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-2 text-sm sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-kaih-muted",
						children: "Nama"
					}),
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: student.nama })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-kaih-muted",
						children: "NISN"
					}),
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "tracking-wide",
						children: student.nisn
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-kaih-muted",
						children: "Kelas"
					}),
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: student.kelas })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-kaih-muted",
						children: "Rata-rata"
					}),
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [average, "%"] }),
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
						className: "text-kaih-gold",
						children: [total, " poin"]
					})
				] })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-2xl border-collapse text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "bg-kaih-paper text-kaih-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border border-kaih-line px-2 py-2",
							children: "Tanggal"
						}),
						HABITS.map((habit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border border-kaih-line px-2 py-2",
							children: habit.short
						}, habit.key)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border border-kaih-line px-2 py-2",
							children: "Poin"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border border-kaih-line px-2 py-2",
							children: "Skor"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.length ? rows.map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "border border-kaih-line px-2 py-2 text-center",
						children: fmtDateShort(log.date)
					}),
					HABITS.map((habit) => {
						const sel = log.selections[habit.key];
						const pts = habit.type === "radio" ? typeof sel === "number" ? habit.options[sel]?.points ?? 0 : 0 : Array.isArray(sel) ? sel.reduce((acc, idx) => acc + (habit.options[idx]?.points ?? 0), 0) : 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-kaih-line px-2 py-2 text-center",
							children: pts
						}, habit.key);
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "border border-kaih-line px-2 py-2 text-center font-bold",
						children: log.totalPoin
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "border border-kaih-line px-2 py-2 text-center font-bold",
						children: [log.skorPersen, "%"]
					})
				] }, log.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: HABITS.length + 3,
					className: "border border-kaih-line px-2 py-6 text-center text-kaih-muted",
					children: "Belum ada jurnal pada periode ini."
				}) }) })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-8 text-center text-sm sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignLine, { role: "Orang tua / wali" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignLine, { role: "Guru pembimbing" })]
		})
	] });
}
function SignLine({ role }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: role }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "border-t border-kaih-muted pt-2 text-kaih-muted",
			children: "(................................)"
		})
	] });
}
var HABIT_ICONS = {
	bangun: Sun,
	ibadah: HeartHandshake,
	olahraga: PersonStanding,
	makan: Utensils,
	belajar: BookOpen,
	masyarakat: Users,
	tidur: Bed
};
var TROPHY_ICONS = {
	awal: Footprints,
	tangga: TrendingUp,
	terakhir: Flag,
	pelopor: Star
};
var moodStyle = {
	smile: "border-kaih-emerald bg-kaih-soft-emerald",
	flat: "border-kaih-gold bg-kaih-soft-amber",
	sad: "border-kaih-danger bg-kaih-soft-danger"
};
function JurnalView() {
	const snapshot = useKaih();
	if (!currentStudent(snapshot)) return null;
	const locked = jurnalLocked(snapshot);
	const score = calcScore(snapshot.selections);
	const shown = Object.keys(snapshot.selections).length ? scoreMeta(score.percent) : scoreMeta(null);
	const ring = 2 * Math.PI * 28;
	const offset = ring - score.percent / 100 * ring;
	const stroke = shown.tone === "good" ? "var(--color-kaih-emerald)" : shown.tone === "mid" ? "var(--color-kaih-amber)" : shown.tone === "low" ? "var(--color-kaih-danger)" : "var(--color-kaih-line)";
	function onSave() {
		const result = saveJurnal();
		if (!result.ok) toast.error(result.message);
		else toast.success(result.message);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold tracking-wide text-kaih-amber uppercase",
					children: "Jurnal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-extrabold",
					children: "Pengisian Jurnal KAIH"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-kaih-muted",
					children: "Tombol paling atas bereaksi senyum, tombol tengah datar, dan tombol paling bawah sedih."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-semibold",
					children: ["Tanggal pencatatan", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						max: todayStr(),
						value: snapshot.jurnalDate,
						onChange: (event) => openJurnal(event.target.value || todayStr()),
						className: "mt-2 block min-h-11 rounded-xl border border-kaih-line bg-kaih-card px-3 text-sm font-semibold"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sm:text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: fmtDateLong(snapshot.jurnalDate)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-sm font-semibold ${locked ? "text-kaih-danger" : "text-kaih-muted"}`,
						children: locked ? "Sudah diisi dan terkunci" : "Belum diisi"
					})]
				})]
			}),
			locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-kaih-soft-danger px-4 py-3 text-sm text-kaih-danger",
				children: "Jurnal tanggal ini sudah disimpan. Setiap tanggal hanya bisa diisi satu kali."
			}) : null,
			snapshot.celebrate !== null && locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl bg-kaih-soft-emerald px-4 py-3 text-sm font-semibold text-kaih-emerald",
				children: [
					snapshot.celebrate >= 80 ? `${MOOD_META.smile.emoji} ` : "",
					"Jurnal tersimpan dengan skor ",
					snapshot.celebrate,
					"%."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: HABITS.map((habit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HabitCard, {
					habit,
					locked
				}, habit.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "mb-2 block text-sm font-bold",
				htmlFor: "refleksi",
				children: "Refleksi harian"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				id: "refleksi",
				rows: 3,
				disabled: locked,
				value: snapshot.refleksi,
				placeholder: "Ceritakan momen berkesan atau tindakan kebaikan hari ini.",
				onChange: (event) => setRefleksi(event.target.value),
				className: "w-full resize-none rounded-xl border border-kaih-line bg-kaih-card px-3 py-3 text-sm outline-none focus:border-kaih-amber disabled:bg-kaih-paper"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col items-stretch gap-4 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative size-16 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							className: "size-16 -rotate-90",
							viewBox: "0 0 64 64",
							"aria-hidden": "true",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "32",
								cy: "32",
								r: "28",
								fill: "none",
								stroke: "var(--color-kaih-line)",
								strokeWidth: "7"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "32",
								cy: "32",
								r: "28",
								fill: "none",
								stroke,
								strokeWidth: "7",
								strokeLinecap: "round",
								strokeDasharray: ring.toFixed(1),
								strokeDashoffset: offset.toFixed(1)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-0 flex items-center justify-center text-sm font-extrabold",
							children: [score.percent, "%"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-kaih-muted",
							children: "Skor hari ini"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-lg font-extrabold",
							children: [
								score.total,
								" / ",
								MAX_TOTAL_POIN,
								" poin"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold text-kaih-gold",
							children: shown.label
						})
					] })]
				}), locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					tone: "secondary",
					onClick: () => toast.error("Jurnal ini sudah terkunci."),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }), "Sudah terkunci"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: onSave,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), "Simpan jurnal hari ini"]
				})]
			})
		]
	});
}
function HabitCard({ habit, locked }) {
	const snapshot = useKaih();
	const sel = snapshot.selections[habit.key];
	const Icon = HABIT_ICONS[habit.key];
	const selectedIndex = habit.type === "radio" && typeof sel === "number" ? sel : null;
	const reaction = snapshot.lastReaction?.habit === habit.key ? snapshot.lastReaction : null;
	const captionIndex = reaction?.index ?? selectedIndex;
	const caption = captionIndex !== null && (habit.type === "radio" || Array.isArray(sel) && sel.includes(captionIndex)) ? MOOD_META[moodFor(captionIndex, habit.options.length)] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-9 items-center justify-center rounded-lg bg-kaih-soft-amber text-kaih-amber",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-extrabold",
					children: habit.title
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: habit.options.map((option, index) => {
					const checked = habit.type === "radio" ? sel === index : Array.isArray(sel) && sel.includes(index);
					const mood = moodFor(index, habit.options.length);
					const popping = reaction?.index === index && reaction.nonce && checked;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": checked,
						onClick: () => {
							if (toggleOption(habit.key, index).locked) toast.error("Jurnal tanggal ini sudah terkunci.");
						},
						className: `flex min-h-11 w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left ${checked ? moodStyle[mood] : "border-kaih-line bg-kaih-card"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `flex size-5 shrink-0 items-center justify-center border-2 ${habit.type === "radio" ? "rounded-full" : "rounded-md"} ${checked ? "border-current" : "border-kaih-line"}`,
								children: checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-current" }) : null
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 text-sm font-medium",
								children: option.label
							}),
							checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `text-xl ${popping ? "mood-pop" : ""}`,
								"aria-hidden": "true",
								children: MOOD_META[mood].emoji
							}, popping ? reaction?.nonce : option.label) : null
						]
					}, option.label);
				})
			}),
			caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mood-pop mt-3 text-sm font-semibold",
				children: [
					caption.emoji,
					" ",
					caption.line
				]
			}, reaction?.nonce ?? selectedIndex) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-kaih-muted",
				children: habit.type === "checkbox" ? "Boleh memilih lebih dari satu." : "Pilih satu jawaban."
			}),
			locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Terkunci"
			}) : null
		]
	});
}
function LencanaView() {
	const snapshot = useKaih();
	const student = currentStudent(snapshot);
	if (!student) return null;
	const mine = logsFor(snapshot.logs, student.nisn);
	const from = snapshot.lencanaFrom <= snapshot.lencanaTo ? snapshot.lencanaFrom : snapshot.lencanaTo;
	const to = snapshot.lencanaFrom <= snapshot.lencanaTo ? snapshot.lencanaTo : snapshot.lencanaFrom;
	const period = mine.filter((log) => log.date >= from && log.date <= to);
	const periodPoints = period.reduce((acc, log) => acc + log.totalPoin, 0);
	const allPoints = mine.reduce((acc, log) => acc + log.totalPoin, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold tracking-wide text-kaih-amber uppercase",
					children: "Prestasi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-extrabold",
					children: "Lencana & Prestasi"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					tone: "secondary",
					onClick: goHome,
					children: "Kembali ke Home"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					kicker: "Periode",
					title: "Perolehan poin"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-semibold",
						children: ["Dari", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							max: todayStr(),
							value: snapshot.lencanaFrom,
							onChange: (event) => setLencanaRange(event.target.value, snapshot.lencanaTo),
							className: "mt-1 block min-h-11 rounded-xl border border-kaih-line px-3"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-semibold",
						children: ["Sampai", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							max: todayStr(),
							value: snapshot.lencanaTo,
							onChange: (event) => setLencanaRange(snapshot.lencanaFrom, event.target.value),
							className: "mt-1 block min-h-11 rounded-xl border border-kaih-line px-3"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm font-bold text-kaih-gold",
					children: [
						periodPoints,
						" poin pada ",
						fmtDateShort(from),
						" – ",
						fmtDateShort(to),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-medium text-kaih-muted",
							children: [
								" · ",
								allPoints,
								" poin sepanjang waktu"
							]
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-sm font-extrabold",
				children: "Piala utama"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: TROPHIES.map((trophy) => {
					const unlocked = periodPoints >= trophy.target;
					const progress = Math.min(100, Math.round(periodPoints / trophy.target * 100));
					const Icon = TROPHY_ICONS[trophy.key];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `mx-auto mb-2 flex size-14 items-center justify-center rounded-full ${unlocked ? "bg-kaih-emerald text-kaih-on" : "bg-kaih-paper text-kaih-muted"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `text-xs font-bold ${unlocked ? "text-kaih-ink" : "text-kaih-muted"}`,
								children: trophy.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-kaih-muted",
								children: [
									periodPoints,
									"/",
									trophy.target
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 h-1.5 overflow-hidden rounded-full bg-kaih-paper",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-kaih-amber",
									style: { width: `${progress}%` }
								})
							})
						]
					}, trophy.key);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-sm font-extrabold",
				children: "Lencana kebiasaan"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: HABITS.map((habit) => {
					const count = badgeCount(period, habit);
					const unlocked = count >= 15;
					const progress = Math.min(100, Math.round(count / 15 * 100));
					const Icon = HABIT_ICONS[habit.key];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `mx-auto mb-2 flex size-14 items-center justify-center rounded-full ${unlocked ? "bg-kaih-soft-emerald text-kaih-emerald" : "bg-kaih-paper text-kaih-muted"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold",
								children: habit.short
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-kaih-muted",
								children: [
									count,
									"/",
									15,
									" kali maksimal"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 h-1.5 overflow-hidden rounded-full bg-kaih-paper",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-kaih-emerald",
									style: { width: `${progress}%` }
								})
							})
						]
					}, habit.key);
				})
			})] })
		]
	});
}
function MonitorView() {
	const snapshot = useKaih();
	const [query, setQuery] = (0, import_react.useState)("");
	const [kelas, setKelas] = (0, import_react.useState)("");
	const classes = (0, import_react.useMemo)(() => Array.from(new Set(snapshot.students.map((student) => student.kelas))).sort(), [snapshot.students]);
	const rows = snapshot.students.filter((student) => {
		return `${student.nama} ${student.nisn} ${student.kelas}`.toLowerCase().includes(query.trim().toLowerCase()) && (!kelas || student.kelas === kelas);
	}).map((student) => summarize(student, snapshot.logs)).sort((a, b) => b.points - a.points);
	const totalLogs = snapshot.logs.length;
	const totalPoints = snapshot.logs.reduce((acc, log) => acc + log.totalPoin, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-kaih-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-kaih-line bg-kaih-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-5xl items-center gap-3 px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/logo-kaih.png",
						alt: "Logo SMA Negeri 1 Kartasura",
						className: "h-12 w-auto object-contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-extrabold",
						children: "Pantauan guru"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-kaih-muted",
						children: "Jurnal KAIH · SMA Negeri 1 Kartasura"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: logout,
						className: "ml-auto inline-flex size-11 items-center justify-center rounded-xl text-kaih-muted hover:bg-kaih-soft-amber",
						"aria-label": "Keluar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" })
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-5xl space-y-4 px-4 py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Siswa terdaftar",
						value: String(snapshot.students.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Entri jurnal",
						value: String(totalLogs)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Total poin",
						value: String(totalPoints)
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-kaih-line bg-kaih-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "relative block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-kaih-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: query,
							onChange: (event) => setQuery(event.target.value),
							placeholder: "Cari nama, NISN, atau kelas",
							className: `${fieldClass} pl-10`
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: kelas,
						onChange: (event) => setKelas(event.target.value),
						className: fieldClass,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Semua kelas"
						}), classes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item,
							children: item
						}, item))]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-xl text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-left text-xs text-kaih-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-kaih-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3",
										children: "NISN"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3",
										children: "Nama"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3",
										children: "Kelas"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 text-center",
										children: "Isi jurnal"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 text-center",
										children: "Total poin"
									})
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-kaih-line last:border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 pr-3 tracking-wide",
									children: row.nisn
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 pr-3 font-semibold",
									children: row.nama
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 pr-3",
									children: row.kelas
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 pr-3 text-center",
									children: row.count
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 text-center font-bold",
									children: row.points
								})
							]
						}, row.nisn)) })]
					})
				})]
			})]
		})]
	});
}
function summarize(student, logs) {
	const mine = logsFor(logs, student.nisn);
	return {
		...student,
		count: mine.length,
		points: mine.reduce((acc, log) => acc + log.totalPoin, 0)
	};
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-kaih-line bg-kaih-card px-4 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-2xl font-extrabold",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold text-kaih-muted",
			children: label
		})]
	});
}
function KaihApp() {
	const snapshot = useKaih();
	(0, import_react.useEffect)(() => {
		boot();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, { position: "top-center" }), !snapshot.ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {}) : snapshot.view === "login" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginScreen, {}) : snapshot.view === "monitor" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonitorView, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		snapshot.view === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {}) : null,
		snapshot.view === "jurnal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JurnalView, {}) : null,
		snapshot.view === "lencana" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LencanaView, {}) : null
	] })] });
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-kaih-paper text-kaih-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/logo-kaih.png",
			alt: "",
			className: "h-20 w-auto object-contain"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold text-kaih-muted",
			children: "Menyiapkan Jurnal KAIH..."
		})]
	});
}
var SplitComponent = KaihApp;
//#endregion
export { SplitComponent as component };

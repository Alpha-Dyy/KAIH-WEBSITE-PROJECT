//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B8HGG4Zk.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DehWwB3D.js", "/assets/rolldown-runtime-hePW80VL.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DehWwB3D.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CBICbayj.js"]
	}
} });
//#endregion
export { tsrStartManifest };
